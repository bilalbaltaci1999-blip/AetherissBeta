import type { inferRouterOutputs } from "@trpc/server";
import type { AppRouter } from "../../api/router";

export type RouterOutputs = inferRouterOutputs<AppRouter>;
export type Account = NonNullable<RouterOutputs["account"]["me"]>;
export type FeedPost = RouterOutputs["social"]["feed"][number];
export type Person = RouterOutputs["social"]["people"][number];
export type Story = RouterOutputs["social"]["stories"][number];
export type Order = RouterOutputs["commerce"]["myOrders"][number];
export type LiveListItem = RouterOutputs["live"]["list"]["live"][number];
export type LiveEndedItem = RouterOutputs["live"]["list"]["ended"][number];
export type LiveRoomInfo = RouterOutputs["live"]["get"];
export type LiveChatMessage = RouterOutputs["live"]["chat"]["messages"][number];
export type LiveGiftEvent = RouterOutputs["live"]["gifts"]["events"][number];
export type LiveGiftLeader = RouterOutputs["live"]["gifts"]["leaderboard"][number];
export type LiveSummary = RouterOutputs["live"]["end"];
export type ReelItem = RouterOutputs["reels"]["catalog"][number];
export type ReelMyStats = RouterOutputs["reels"]["myStats"];
