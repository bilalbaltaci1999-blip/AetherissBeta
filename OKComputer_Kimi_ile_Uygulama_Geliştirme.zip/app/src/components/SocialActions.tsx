import { useState, type FormEvent } from "react";
import { Flag, UserMinus, UserPlus } from "lucide-react";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { trpc } from "@/providers/trpc";

export function FollowButton({ userId, following, compact = false }: { userId: number; following: boolean; compact?: boolean }) {
  const utils = trpc.useUtils();
  const toggle = trpc.social.toggleFollow.useMutation({
    onSuccess: async (result) => {
      await Promise.all([utils.social.people.invalidate(), utils.social.feed.invalidate(), utils.social.mySocialStats.invalidate()]);
      toast.success(result.following ? "Takip ediliyor" : "Takip çıkarıldı");
    },
    onError: (error) => toast.error(error.message),
  });

  const className = compact
    ? `inline-flex min-h-9 items-center gap-1.5 rounded-full border px-3 text-xs font-semibold transition-all active:scale-95 ${following ? "border-[#40aaff] text-[#40aaff]" : "border-white/20 text-white hover:border-[#40aaff] hover:text-[#40aaff]"}`
    : `inline-flex min-h-10 items-center gap-2 rounded-md px-4 text-sm font-semibold transition-all active:scale-95 ${following ? "border border-[#40aaff] text-[#40aaff]" : "btn-primary"}`;

  return (
    <button className={className} onClick={() => toggle.mutate({ userId })} disabled={toggle.isPending} aria-label={following ? "Takibi bırak" : "Takip et"}>
      {following ? <UserMinus size={compact ? 14 : 16} /> : <UserPlus size={compact ? 14 : 16} />}
      {toggle.isPending ? "İşleniyor…" : following ? "Takiptesin" : "Takip et"}
    </button>
  );
}

const reportReasons = [
  "Nefret söylemi veya taciz",
  "Şiddet veya tehlike",
  "Spam veya yanıltıcı içerik",
  "Telif veya izinsiz paylaşım",
  "Diğer",
];

export function ReportButton({ targetType, targetId, title }: { targetType: "post" | "story" | "user"; targetId: number; title: string }) {
  const [open, setOpen] = useState(false);
  const [reason, setReason] = useState(reportReasons[0]);
  const [details, setDetails] = useState("");
  const report = trpc.social.report.useMutation({
    onSuccess: () => {
      setOpen(false);
      setDetails("");
      toast.success("Şikâyetin incelenmek üzere alındı");
    },
    onError: (error) => toast.error(error.message),
  });

  function submit(event: FormEvent) {
    event.preventDefault();
    report.mutate({ targetType, targetId, reason, details });
  }

  return (
    <>
      <button className="icon-btn" onClick={() => setOpen(true)} aria-label={`${title} bildir`} title="Şikâyet et">
        <Flag size={18} />
      </button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="border-white/10 bg-[#121212] text-white sm:rounded-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><Flag size={18} className="text-[#ff6c88]" />İçeriği bildir</DialogTitle>
            <DialogDescription className="text-white/50">{title} için topluluk kurallarına aykırı olduğunu düşündüğün noktayı kısaca anlat.</DialogDescription>
          </DialogHeader>
          <form onSubmit={submit} className="space-y-4">
            <div>
              <label className="field-label" htmlFor={`report-reason-${targetId}`}>Sebep</label>
              <select id={`report-reason-${targetId}`} className="field" value={reason} onChange={(event) => setReason(event.target.value)}>
                {reportReasons.map((item) => <option key={item} value={item}>{item}</option>)}
              </select>
            </div>
            <div>
              <label className="field-label" htmlFor={`report-details-${targetId}`}>Açıklama</label>
              <textarea id={`report-details-${targetId}`} className="field" value={details} onChange={(event) => setDetails(event.target.value)} placeholder="Ne olduğunu ve neden bildirdiğini yaz…" maxLength={1200} />
            </div>
            <button className="btn-danger w-full" disabled={report.isPending}>{report.isPending ? "Gönderiliyor…" : "Şikâyeti gönder"}</button>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
}
