import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Bookmark, ChevronDown, Clapperboard, Eye, Heart, Pause, Play, RotateCcw, Share2, Volume2, VolumeX } from "lucide-react";
import { toast } from "sonner";
import { formatWatch } from "@/lib/format";
import { trpc } from "@/providers/trpc";
import type { ReelItem } from "@/types";
import { Avatar } from "./Brand";

function formatClock(totalSeconds: number) {
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${minutes}:${String(seconds).padStart(2, "0")}`;
}

type Burst = { id: number; x: number; y: number };

function ReelCard({
  reel,
  active,
  muted,
  onMuteToggle,
  onToggleLike,
  onEnded,
}: {
  reel: ReelItem;
  active: boolean;
  muted: boolean;
  onMuteToggle: () => void;
  onToggleLike: () => void;
  onEnded: () => void;
}) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const shellRef = useRef<HTMLDivElement>(null);
  const [paused, setPaused] = useState(false);
  const [ended, setEnded] = useState(false);
  const [position, setPosition] = useState(0);
  const [bursts, setBursts] = useState<Burst[]>([]);
  const tapTimer = useRef<number | undefined>(undefined);
  const burstCounter = useRef(0);
  const flushedRef = useRef(0);
  const activatedAtRef = useRef(0);

  const record = trpc.reels.recordView.useMutation();
  const saveProgress = trpc.reels.saveProgress.useMutation();

  const flushWatch = useCallback(
    (final = false) => {
      const video = videoRef.current;
      if (!video) return;
      const watched = Math.floor(video.currentTime) - flushedRef.current;
      if (watched > 0) {
        record.mutate({ reelId: reel.id, watchSeconds: watched });
        flushedRef.current += watched;
      }
      if (final) saveProgress.mutate({ reelId: reel.id, positionSeconds: Math.floor(video.currentTime) });
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [reel.id],
  );

  // Aktifleşme: konumdan devam et + izlemeye başla
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    if (active) {
      activatedAtRef.current = Date.now();
      flushedRef.current = 0;
      if (reel.progressSeconds > 0 && reel.progressSeconds < reel.durationSec - 1) {
        video.currentTime = reel.progressSeconds;
        setPosition(reel.progressSeconds);
      }
      video.play().catch(() => setPaused(true));
      setPaused(false);
      setEnded(false);
    } else {
      flushWatch(true);
      video.pause();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [active, reel.id]);

  // Aktifken 5 sn'de bir izlenme kaydı
  useEffect(() => {
    if (!active) return;
    const timer = window.setInterval(() => {
      const video = videoRef.current;
      if (video && !video.paused && !video.ended) flushWatch();
    }, 5000);
    return () => window.clearInterval(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [active, reel.id]);

  // Sekme gizlenirse duraklat ve kaydet
  useEffect(() => {
    if (!active) return;
    const onVisibility = () => {
      const video = videoRef.current;
      if (!video) return;
      if (document.hidden) {
        video.pause();
        flushWatch(true);
      } else if (!paused) {
        video.play().catch(() => undefined);
      }
    };
    document.addEventListener("visibilitychange", onVisibility);
    return () => document.removeEventListener("visibilitychange", onVisibility);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [active, paused, reel.id]);

  function seek(clientX: number) {
    const video = videoRef.current;
    const bar = shellRef.current?.querySelector("[data-progress]");
    if (!video || !bar) return;
    const rect = bar.getBoundingClientRect();
    const ratio = Math.min(1, Math.max(0, (clientX - rect.left) / rect.width));
    video.currentTime = ratio * video.duration;
    setPosition(video.currentTime);
  }

  function handleTap(event: React.MouseEvent) {
    const video = videoRef.current;
    if (!video) return;
    if (tapTimer.current) {
      window.clearTimeout(tapTimer.current);
      tapTimer.current = undefined;
      // Çift dokunuş: beğen
      const rect = (event.currentTarget as HTMLElement).getBoundingClientRect();
      burstCounter.current += 1;
      const burst = { id: burstCounter.current, x: event.clientX - rect.left, y: event.clientY - rect.top };
      setBursts((items) => [...items, burst]);
      window.setTimeout(() => setBursts((items) => items.filter((item) => item.id !== burst.id)), 800);
      if (!reel.liked) onToggleLike();
      return;
    }
    tapTimer.current = window.setTimeout(() => {
      tapTimer.current = undefined;
      if (video.paused) {
        video.play().catch(() => undefined);
        setPaused(false);
      } else {
        video.pause();
        setPaused(true);
        flushWatch(true);
      }
    }, 240);
  }

  function restart() {
    const video = videoRef.current;
    if (!video) return;
    video.currentTime = 0;
    video.play().catch(() => undefined);
    setEnded(false);
    setPaused(false);
    saveProgress.mutate({ reelId: reel.id, positionSeconds: 0 });
  }

  async function share() {
    try {
      await navigator.clipboard.writeText(`${reel.title} — @${reel.handle} · ${window.location.origin}/?reel=${reel.id}`);
      toast.success("Reels bağlantısı kopyalandı");
    } catch {
      toast.error("Bağlantı kopyalanamadı");
    }
  }

  const percent = reel.durationSec ? Math.min(100, (position / reel.durationSec) * 100) : 0;

  return (
    <div ref={shellRef} className="reel-shell" onClick={handleTap} role="button" tabIndex={0} aria-label={`${reel.title} reels videosu`}>
      <video
        ref={videoRef}
        className="reel-video"
        src={reel.video}
        poster={reel.poster}
        playsInline
        loop={false}
        muted={muted}
        preload={active ? "auto" : "metadata"}
        onTimeUpdate={(event) => setPosition(event.currentTarget.currentTime)}
        onEnded={() => {
          setEnded(true);
          flushWatch(true);
          onEnded();
        }}
      />

      {/* Karartmalar */}
      <div className="pointer-events-none absolute inset-x-0 top-0 h-24 bg-gradient-to-b from-black/70 to-transparent" />
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-56 bg-gradient-to-t from-black/90 via-black/40 to-transparent" />

      {/* Kalp patlamaları */}
      {bursts.map((burst) => (
        <span key={burst.id} className="reel-burst" style={{ left: burst.x, top: burst.y }}>
          <Heart size={84} fill="#ff6c88" color="#ff6c88" />
        </span>
      ))}

      {/* Duraklatıldı rozeti */}
      {paused && !ended && (
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
          <span className="flex h-20 w-20 items-center justify-center rounded-full bg-black/55 backdrop-blur-sm">
            <Pause size={34} className="text-white" />
          </span>
        </div>
      )}

      {/* Bitti ekranı */}
      {ended && (
        <div className="absolute inset-0 z-10 flex flex-col items-center justify-center gap-4 bg-black/60 backdrop-blur-sm">
          <Clapperboard size={38} className="text-white/85" />
          <p className="text-xl font-semibold">Reels bitti</p>
          <div className="flex items-center gap-2">
            <button className="btn-primary" onClick={(event) => { event.stopPropagation(); restart(); }}>
              <RotateCcw size={17} />Baştan izle
            </button>
            <button className="btn-secondary" onClick={(event) => { event.stopPropagation(); onEnded(); }}>
              Sıradaki<ChevronDown size={17} />
            </button>
          </div>
        </div>
      )}

      {/* Sağ aksiyon kolonu */}
      <div className="absolute bottom-24 right-3 z-10 flex flex-col items-center gap-3">
        <button
          className={`reel-action ${reel.liked ? "text-[#ff6c88]" : "text-white"}`}
          onClick={(event) => { event.stopPropagation(); onToggleLike(); }}
          aria-label={reel.liked ? "Beğeniyi kaldır" : "Reels beğen"}
          aria-pressed={reel.liked}
        >
          <Heart size={26} fill={reel.liked ? "currentColor" : "none"} className={reel.liked ? "animate-like-pop" : ""} />
          <span className="mono text-[11px]">{reel.likeCount}</span>
        </button>
        <span className="reel-action text-white" aria-label={`${reel.viewCount} görüntülenme`}>
          <Eye size={26} />
          <span className="mono text-[11px]">{reel.viewCount}</span>
        </span>
        <button className="reel-action text-white" onClick={(event) => { event.stopPropagation(); share(); }} aria-label="Reels paylaş">
          <Share2 size={24} />
          <span className="mono text-[11px]">Paylaş</span>
        </button>
        <button className="reel-action text-white" onClick={(event) => { event.stopPropagation(); onMuteToggle(); }} aria-label={muted ? "Sesi aç" : "Sesi kapat"}>
          {muted ? <VolumeX size={24} /> : <Volume2 size={24} />}
          <span className="mono text-[11px]">{muted ? "Sesli" : "Sessiz"}</span>
        </button>
      </div>

      {/* Alt bilgi şeridi */}
      <div className="absolute inset-x-0 bottom-0 z-10 p-4 pb-5">
        <div className="flex items-center gap-2.5">
          <Avatar name={reel.author} size={34} />
          <div className="min-w-0">
            <p className="flex items-center gap-2 text-sm font-semibold">
              {reel.author}
              <span className="badge">{reel.category}</span>
            </p>
            <p className="mono text-[10px] text-white/60">@{reel.handle}</p>
          </div>
        </div>
        <h2 className="mt-2.5 max-w-[26ch] text-lg font-semibold leading-tight">{reel.title}</h2>
        {reel.progressSeconds > 0 && !active && (
          <p className="mono mt-1.5 flex items-center gap-1.5 text-[10px] text-[#40aaff]">
            <Play size={11} />Kaldığın yer: {formatClock(Math.min(reel.progressSeconds, reel.durationSec))}
          </p>
        )}
        {/* İlerleme çubuğu */}
        <div
          data-progress
          className="group relative mt-3 h-6 cursor-pointer"
          onClick={(event) => { event.stopPropagation(); seek(event.clientX); }}
          role="slider"
          aria-label="Video ilerlemesi"
          aria-valuemin={0}
          aria-valuemax={reel.durationSec}
          aria-valuenow={Math.floor(position)}
          tabIndex={0}
        >
          <div className="absolute inset-x-0 top-1/2 h-[3px] -translate-y-1/2 rounded bg-white/25 transition-all group-hover:h-[5px]">
            <div className="h-full rounded bg-[#40aaff]" style={{ width: `${percent}%` }} />
          </div>
        </div>
        <div className="mono mt-0.5 flex items-center justify-between text-[10px] text-white/60">
          <span>{formatClock(Math.floor(position))}</span>
          <span>{formatClock(reel.durationSec)}</span>
        </div>
      </div>
      {activatedAtRef.current > 0 && null}
    </div>
  );
}

export default function ReelsView() {
  const [activeIndex, setActiveIndex] = useState(0);
  const [muted, setMuted] = useState(true);
  const [autoAdvance, setAutoAdvance] = useState(true);
  const [category, setCategory] = useState<string>("Tümü");
  const feedRef = useRef<HTMLDivElement>(null);
  const observedRef = useRef<Map<number, HTMLDivElement>>(new Map());

  const utils = trpc.useUtils();
  const catalog = trpc.reels.catalog.useQuery(undefined, { refetchInterval: 30000 });
  const myStats = trpc.reels.myStats.useQuery();
  const toggleLike = trpc.reels.toggleLike.useMutation({
    onSuccess: () => utils.reels.catalog.invalidate(),
    onError: (error) => toast.error(error.message),
  });

  const categories = useMemo(() => ["Tümü", ...Array.from(new Set((catalog.data ?? []).map((reel) => reel.category)))], [catalog.data]);
  const reels = useMemo(
    () => (catalog.data ?? []).filter((reel) => category === "Tümü" || reel.category === category),
    [catalog.data, category],
  );

  // Görünürlük gözlemcisi: en çok görünen kart aktif
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting && entry.intersectionRatio >= 0.6) {
            const index = Number((entry.target as HTMLElement).dataset.index);
            if (!Number.isNaN(index)) setActiveIndex(index);
          }
        }
      },
      { root: feedRef.current, threshold: [0.6] },
    );
    observedRef.current.forEach((element) => observer.observe(element));
    return () => observer.disconnect();
  }, [reels.length]);

  function scrollTo(index: number) {
    const element = observedRef.current.get(index);
    element?.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function handleEnded() {
    if (!autoAdvance) return;
    const next = activeIndex + 1;
    if (next < reels.length) scrollTo(next);
    else toast.info("Bu kategorideki reelsler bitti", { description: "Başka bir kategori dene ya da baştan izle." });
  }

  // Klavye kısayolları
  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      const target = event.target as HTMLElement;
      if (["INPUT", "TEXTAREA", "SELECT"].includes(target.tagName)) return;
      if (event.key === "ArrowDown") {
        event.preventDefault();
        scrollTo(Math.min(activeIndex + 1, reels.length - 1));
      }
      if (event.key === "ArrowUp") {
        event.preventDefault();
        scrollTo(Math.max(activeIndex - 1, 0));
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [activeIndex, reels.length]);

  if (catalog.isLoading) {
    return (
      <div className="view-enter p-4 sm:p-7">
        <p className="mono muted text-xs">REELS / Yükleniyor…</p>
        <div className="mx-auto mt-5 aspect-[9/14] max-h-[70dvh] w-full max-w-[420px] animate-pulse rounded-xl border border-white/10 bg-white/[0.04]" />
      </div>
    );
  }

  return (
    <div className="view-enter flex h-[calc(100dvh-150px)] min-h-[520px] flex-col lg:h-[calc(100dvh-70px)]">
      {/* Üst şerit */}
      <div className="flex flex-wrap items-center gap-2 border-b border-white/10 px-4 py-3 sm:px-7">
        <p className="mono mr-auto flex items-center gap-2 text-xs text-white/70">
          <Clapperboard size={15} className="blue" />
          REELS · {reels.length} video
        </p>
        {myStats.data && myStats.data.watchSeconds > 0 && (
          <span className="badge status-info"><Eye size={12} />{myStats.data.reelsWatched} reels · {formatWatch(myStats.data.watchSeconds)} izlendi</span>
        )}
        <label className="flex cursor-pointer items-center gap-2 text-xs text-white/70">
          <input
            type="checkbox"
            className="h-4 w-4 accent-[#40aaff]"
            checked={autoAdvance}
            onChange={(event) => setAutoAdvance(event.target.checked)}
          />
          Otomatik sıradaki
        </label>
        {muted && (
          <button className="btn-ghost min-h-8 px-2 text-xs" onClick={() => setMuted(false)}>
            <VolumeX size={14} />Sessizde oynuyor
          </button>
        )}
      </div>

      {/* Kategori filtreleri */}
      <div className="flex gap-2 overflow-x-auto border-b border-white/10 px-4 py-2.5 sm:px-7">
        {categories.map((item) => (
          <button
            key={item}
            className={`badge shrink-0 transition-colors ${category === item ? "status-info border-[#40aaff]" : "hover:text-white"}`}
            onClick={() => { setCategory(item); setActiveIndex(0); }}
          >
            {item}
          </button>
        ))}
      </div>

      {/* Dikey kaydırmalı akış */}
      <div ref={feedRef} className="reel-feed min-h-0 flex-1">
        {reels.map((reel, index) => (
          <div
            key={reel.id}
            data-index={index}
            ref={(element) => {
              if (element) observedRef.current.set(index, element);
              else observedRef.current.delete(index);
            }}
            className="reel-snap"
          >
            <ReelCard
              reel={reel}
              active={index === activeIndex}
              muted={muted}
              onMuteToggle={() => setMuted((value) => !value)}
              onToggleLike={() => toggleLike.mutate({ reelId: reel.id })}
              onEnded={handleEnded}
            />
          </div>
        ))}
        {reels.length === 0 && (
          <div className="flex h-full items-center justify-center p-8 text-center">
            <p className="muted">Bu kategoride reels yok.</p>
          </div>
        )}
      </div>

      {/* Devam et şeridi */}
      {myStats.data && myStats.data.inProgress.length > 0 && (
        <div className="border-t border-white/10 px-4 py-3 sm:px-7">
          <p className="mono muted mb-2 flex items-center gap-1.5 text-[10px] uppercase tracking-[0.12em]"><Bookmark size={11} />İzlemeye devam et</p>
          <div className="flex gap-2 overflow-x-auto pb-1">
            {myStats.data.inProgress.map((item) => (
              <button
                key={item.reelId}
                className="group relative h-20 w-14 shrink-0 overflow-hidden rounded-md border border-white/10"
                onClick={() => {
                  const index = reels.findIndex((reel) => reel.id === item.reelId);
                  if (index >= 0) scrollTo(index);
                  else toast.info("Bu reels seçili kategoride değil", { description: "Kategoriyi 'Tümü' yaparak bulabilirsin." });
                }}
                aria-label={`${item.title} kaldığın yerden izle`}
              >
                <img src={item.poster} alt="" className="h-full w-full object-cover transition-transform group-hover:scale-105" />
                <span className="absolute inset-x-0 bottom-0 h-1 bg-white/25">
                  <span className="block h-full bg-[#40aaff]" style={{ width: `${item.percent}%` }} />
                </span>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
