import { useEffect, useMemo, useState, type FormEvent } from "react";
import { ArrowRight, Check, CircleAlert, CircleCheck, Eye, EyeOff, KeyRound, Loader2, LockKeyhole, Mail, ShieldCheck } from "lucide-react";
import { Link } from "react-router";
import { toast } from "sonner";
import { trpc } from "@/providers/trpc";
import { Logo } from "./Brand";

type Mode = "login" | "register" | "forgot" | "reset";

const HANDLE_RE = /^[a-zA-Z0-9_]{3,24}$/;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

function passwordScore(password: string): number {
  if (!password) return 0;
  let score = 0;
  if (password.length >= 8) score += 1;
  if (password.length >= 12) score += 1;
  if (/[A-Z]/.test(password) && /[a-z]/.test(password)) score += 1;
  if (/[0-9]/.test(password)) score += 1;
  if (/[^A-Za-z0-9]/.test(password)) score += 1;
  if (score <= 2) return score === 0 ? 0 : 1;
  if (score === 3) return 2;
  if (score === 4) return 3;
  return 4;
}

const SCORE_LABELS = ["", "Zayıf", "Orta", "Güçlü", "Çok güçlü"];

export default function AuthScreen({ resetToken, onAuthenticated }: { resetToken: string | null; onAuthenticated: () => void }) {
  const [mode, setMode] = useState<Mode>(resetToken ? "reset" : "login");
  const [identifier, setIdentifier] = useState("");
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [handle, setHandle] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [resetMessage, setResetMessage] = useState("");
  const [previewUrl, setPreviewUrl] = useState<string | undefined>();
  const [error, setError] = useState("");
  const [handleTouched, setHandleTouched] = useState(false);

  const login = trpc.account.login.useMutation({
    onSuccess: onAuthenticated,
    onError: (err) => setError(err.message),
  });
  const register = trpc.account.register.useMutation({
    onSuccess: onAuthenticated,
    onError: (err) => setError(err.message),
  });
  const forgot = trpc.account.forgotPassword.useMutation({
    onSuccess: (result) => {
      setResetMessage(result.message);
      setPreviewUrl(result.previewUrl);
    },
    onError: (err) => setError(err.message),
  });
  const reset = trpc.account.resetPassword.useMutation({
    onSuccess: () => {
      window.history.replaceState({}, "", "/");
      setMode("login");
      setPassword("");
      toast.success("Şifren yenilendi. Yeni şifrenle giriş yapabilirsin.");
    },
    onError: (err) => setError(err.message),
  });

  const handleValid = HANDLE_RE.test(handle);
  const checkHandle = trpc.account.checkHandle.useQuery(
    { handle: handle.replace(/^@/, "").toLowerCase() },
    { enabled: mode === "register" && handleValid, staleTime: 30_000 },
  );
  const emailValid = EMAIL_RE.test(email);
  const score = useMemo(() => passwordScore(password), [password]);
  const busy = login.isPending || register.isPending || forgot.isPending || reset.isPending;
  const switchMode = (next: Mode) => {
    setMode(next);
    setError("");
    setResetMessage("");
    setPreviewUrl(undefined);
    if (next !== "register") setHandleTouched(false);
  };

  // Kullanıcı adı alanını düzenleyince canlı kontrolü etkinleştir
  useEffect(() => setHandleTouched(true), [handle]);

  function submit(event: FormEvent) {
    event.preventDefault();
    setError("");
    if (mode === "login") login.mutate({ identifier, password });
    if (mode === "register") {
      if (!handleValid) { setError("Kullanıcı adı 3–24 karakter olmalı: harf, rakam ve _ kullanabilirsin."); return; }
      if (checkHandle.data && !checkHandle.data.available) { setError("Bu kullanıcı adı az önce alındı; başka bir tane dene."); return; }
      register.mutate({ name, handle: handle.replace(/^@/, ""), email, password });
    }
    if (mode === "forgot") forgot.mutate({ email });
    if (mode === "reset" && resetToken) reset.mutate({ token: resetToken, password });
  }

  function demoLogin() {
    setError("");
    login.mutate({ identifier: "demo@aetheris.social", password: "Demo123!" });
  }

  const titles: Record<Mode, { title: string; subtitle: string }> = {
    login: { title: "Tekrar hoş geldin.", subtitle: "Topluluğuna kaldığın yerden devam et." },
    register: { title: "Yerini al.", subtitle: "Ücretsiz hesabını bir dakikadan kısa sürede oluştur." },
    forgot: { title: "Şifreni yenile.", subtitle: "Kayıtlı e-posta adresine aetherisback2027@gmail.com üzerinden güvenli bir bağlantı gönderelim." },
    reset: { title: "Yeni şifre belirle.", subtitle: "Bağlantı tek kullanımlıktır ve 30 dakika geçerlidir." },
  };

  const handleHint = !handleTouched || !handle ? null : !handleValid ? (
    <p className="field-hint err"><CircleAlert size={13} />3–24 karakter: harf, rakam ve _</p>
  ) : checkHandle.isLoading ? (
    <p className="field-hint busy"><Loader2 size={13} className="animate-spin" />Kontrol ediliyor…</p>
  ) : checkHandle.data?.available ? (
    <p className="field-hint ok"><CircleCheck size={13} />@{handle.replace(/^@/, "")} müsait</p>
  ) : (
    <p className="field-hint err"><CircleAlert size={13} />Bu kullanıcı adı alınmış</p>
  );

  return (
    <main className="auth-layout">
      <section className="auth-editorial checkerband" aria-label="Aetheris tanıtımı">
        <div className="aurora" aria-hidden="true"><i /><i /><i /></div>
        <div className="relative"><Logo /></div>
        <div className="relative max-w-[720px]">
          <p className="mono blue mb-7 text-xs font-semibold uppercase tracking-[0.18em]">Topluluğun, senin ritminde</p>
          <h1 className="auth-word">Daha az gürültü.<br /><span className="blue">Daha çok sen.</span></h1>
          <p className="muted mt-8 max-w-[52ch] text-lg leading-relaxed">
            İşine, fikrine ve topluluğuna odaklan. Aetheris nitelikli bağlantılar ile yaratıcı üretimi aynı sakin alanda buluşturur. Canlı yayınlarda hediyeler uçuşsun, sohbet ve destek anında yanında olsun.
          </p>
        </div>
        <div className="relative grid grid-cols-3 gap-5 border-t border-white/10 pt-6">
          {[['Açık', 'ücretsiz başlangıç'], ['Güvenli', 'canlı doğrulamalı kayıt'], ['Canlı', 'yayın, hediye ve destek']].map(([title, text]) => (
            <div key={title}><strong className="block text-sm">{title}</strong><span className="mono muted mt-1 block text-[11px]">{text}</span></div>
          ))}
        </div>
      </section>

      <section className="auth-form-side">
        <div className="auth-form-box">
          <div className="mb-10 flex items-center justify-between lg:hidden"><Logo /><span className="badge">BETA</span></div>
          <div className="mb-8" key={`title-${mode}`}>
            <p className="mono blue mb-3 text-xs uppercase tracking-[0.16em]">Hesap erişimi</p>
            <h2 className="auth-mode-enter text-4xl font-semibold tracking-[-0.04em]">{titles[mode].title}</h2>
            <p className="muted mt-2">{titles[mode].subtitle}</p>
          </div>

          <form key={mode} onSubmit={submit} className="auth-mode-enter space-y-4" noValidate={false}>
            {mode === "register" && (
              <div className="grid gap-4 sm:grid-cols-2">
                <div><label className="field-label" htmlFor="reg-name">Ad soyad</label><input id="reg-name" className="field" value={name} onChange={(e) => setName(e.target.value)} required minLength={2} autoComplete="name" placeholder="Adın ve soyadın" /></div>
                <div>
                  <label className="field-label" htmlFor="reg-handle">Kullanıcı adı</label>
                  <input id="reg-handle" className="field" value={handle} onChange={(e) => setHandle(e.target.value)} required pattern="[a-zA-Z0-9_]{3,24}" autoComplete="username" placeholder="kullaniciadi" />
                  {handleHint}
                </div>
              </div>
            )}
            {(mode === "register" || mode === "forgot") && (
              <div>
                <label className="field-label" htmlFor="auth-email">E-posta</label>
                <div className="relative"><Mail className="muted pointer-events-none absolute left-3.5 top-3.5" size={18} /><input id="auth-email" type="email" className="field pl-11" value={email} onChange={(e) => setEmail(e.target.value)} required autoComplete="email" placeholder="ornek@eposta.com" /></div>
                {mode === "register" && email && (
                  <p className={`field-hint ${emailValid ? "ok" : "err"}`}>{emailValid ? <><CircleCheck size={13} />E-posta biçimi uygun</> : <><CircleAlert size={13} />Geçerli bir e-posta gir</>}</p>
                )}
              </div>
            )}
            {mode === "login" && (
              <div><label className="field-label" htmlFor="login-id">E-posta veya kullanıcı adı</label><input id="login-id" className="field" value={identifier} onChange={(e) => setIdentifier(e.target.value)} required autoComplete="username" placeholder="ornek@eposta.com" /></div>
            )}
            {(mode === "login" || mode === "register" || mode === "reset") && (
              <div>
                <label className="field-label" htmlFor="auth-password">{mode === "reset" ? "Yeni şifre" : "Şifre"}</label>
                <div className="relative"><LockKeyhole className="muted pointer-events-none absolute left-3.5 top-3.5" size={18} /><input id="auth-password" type={showPassword ? "text" : "password"} className="field px-11" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={mode === "login" ? 1 : 8} autoComplete={mode === "login" ? "current-password" : "new-password"} placeholder="En az 8 karakter" /><button type="button" className="icon-btn absolute right-0.5 top-0.5" onClick={() => setShowPassword((value) => !value)} aria-label={showPassword ? "Şifreyi gizle" : "Şifreyi göster"}>{showPassword ? <EyeOff size={18} /> : <Eye size={18} />}</button></div>
                {mode !== "login" && (
                  <>
                    <div className="pw-meter" data-score={score} aria-hidden="true"><span /><span /><span /><span /></div>
                    <p className="pw-hint mono muted">{password ? SCORE_LABELS[score] : "En az 8 karakter, bir büyük harf ve bir rakam."}</p>
                  </>
                )}
              </div>
            )}
            {mode === "register" && <label className="muted flex cursor-pointer items-start gap-3 text-sm"><input type="checkbox" required className="mt-1 h-4 w-4 accent-[#40aaff]" /><span>Kullanım şartlarını, gizlilik politikasını ve topluluk kurallarını kabul ediyorum.</span></label>}
            {mode === "login" && <div className="flex justify-end"><button type="button" onClick={() => switchMode("forgot")} className="blue min-h-11 text-sm font-medium hover:underline">Şifremi unuttum</button></div>}
            {error && <p role="alert" className="border border-red-500/30 bg-red-500/10 px-3 py-2 text-sm text-red-200">{error}</p>}
            {resetMessage && <div role="status" className="border border-[#40aaff]/30 bg-[#40aaff]/10 p-4 text-sm"><p>{resetMessage}</p>{previewUrl && <a className="blue mt-3 inline-block font-semibold underline" href={previewUrl}>Geliştirme testi: sıfırlama bağlantısını aç</a>}</div>}
            <button className="btn-primary w-full" disabled={busy || (mode === "register" && handleValid && checkHandle.data !== undefined && !checkHandle.data.available)}>{busy ? "İşleniyor…" : mode === "login" ? "Giriş yap" : mode === "register" ? "Hesabımı oluştur" : mode === "forgot" ? "Bağlantı gönder" : "Şifreyi yenile"}<ArrowRight size={18} /></button>
          </form>

          {mode === "login" && (
            <>
              <div className="my-6 flex items-center gap-3"><span className="h-px flex-1 bg-white/10" /><span className="mono muted text-[11px]">veya</span><span className="h-px flex-1 bg-white/10" /></div>
              <button className="btn-secondary w-full" onClick={demoLogin} disabled={busy}><ShieldCheck size={18} />Demo hesabıyla keşfet</button>
              <Link to="/login" className="btn-ghost mt-2 w-full text-sm">Kimi hesabıyla giriş yap</Link>
            </>
          )}
          <div className="muted mt-7 text-center text-sm">
            {mode === "login" && <>Henüz hesabın yok mu? <button className="blue min-h-11 font-semibold" onClick={() => switchMode("register")}>Ücretsiz kaydol</button></>}
            {mode === "register" && <>Zaten üye misin? <button className="blue min-h-11 font-semibold" onClick={() => switchMode("login")}>Giriş yap</button></>}
            {(mode === "forgot" || mode === "reset") && <button className="btn-ghost w-full" onClick={() => switchMode("login")}><KeyRound size={16} />Giriş ekranına dön</button>}
          </div>
          <div className="mono muted mt-8 flex items-center justify-center gap-2 text-[10px] uppercase tracking-wider"><Check size={13} />Güvenli oturum · Canlı kullanıcı adı kontrolü · Tek kullanımlık sıfırlama</div>
        </div>
      </section>
    </main>
  );
}
