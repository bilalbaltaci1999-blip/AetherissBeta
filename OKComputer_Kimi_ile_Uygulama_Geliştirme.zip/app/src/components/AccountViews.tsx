import { useEffect, useState, type ChangeEvent, type FormEvent } from "react";
import { BadgeCheck, BarChart3, CalendarDays, Camera, Check, Coins, Copy, CreditCard, Crown, FileCheck2, Gem, KeyRound, Landmark, Lock, LogOut, Pencil, Shield, XCircle } from "lucide-react";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { money, orderStatus, relativeTime, formatWatch } from "@/lib/format";
import { trpc } from "@/providers/trpc";
import type { Account } from "@/types";
import { Avatar, VerifiedBadge } from "./Brand";
import PostCard from "./PostCard";

const plusFeatures = ["Mavi doğrulama rozeti", "1.200 karaktere kadar gönderi", "Öncelikli destek", "Gelişmiş profil görünümü", "Erken erişim özellikleri"];

function fileToBase64(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result).split(",")[1]);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

export function PremiumView({ user }: { user: Account }) {
  const [plan, setPlan] = useState<"plus_monthly" | "plus_yearly">("plus_monthly");
  const [created, setCreated] = useState<{ referenceCode: string; amount: number; payment: { accountName: string; bankName: string; iban: string } } | null>(null);
  const orders = trpc.commerce.myOrders.useQuery();
  const create = trpc.commerce.createOrder.useMutation({ onSuccess: (result) => { setCreated(result); orders.refetch(); toast.success("Sipariş ve ödeme referansı oluşturuldu"); }, onError: (e) => toast.error(e.message) });
  const markSent = trpc.commerce.markPaymentSent.useMutation({ onSuccess: () => { orders.refetch(); setCreated(null); toast.success("Ödeme bildirimin incelenmeye alındı"); }, onError: (e) => toast.error(e.message) });
  const price = plan === "plus_monthly" ? 12900 : 129000;

  async function copy(text: string) { await navigator.clipboard.writeText(text); toast.success("Kopyalandı"); }

  return <div className="view-enter p-4 sm:p-7">
    <section className="checkerband border-b border-white/10 pb-8">
      <div className="flex flex-wrap items-center justify-between gap-4"><div><p className="mono blue text-xs uppercase tracking-[0.15em]">Aetheris Plus</p><h1 className="mt-3 max-w-[14ch] text-4xl font-semibold leading-[1.02] tracking-[-0.05em]">Daha görünür. Daha üretken.</h1></div>{user.plan === "plus" ? <span className="badge status-success"><Crown size={14} />Plus aktif</span> : <span className="badge">Şu an ücretsiz</span>}</div>
      <p className="mt-4 max-w-[55ch] text-white/70">Mavi tik ve işine yarayan ayrıcalıklar. Gizli ücret yok, otomatik kart çekimi yok; ödemeni Havale/EFT ile yönet.</p>
    </section>
    <section className="mt-7 grid gap-8 lg:grid-cols-[1.1fr_0.9fr]">
      <div><h2 className="mb-4 text-xl font-semibold">Üyeliğine dahil olanlar</h2><ul className="border-t border-white/10">{plusFeatures.map((feature) => <li key={feature} className="flex items-center gap-3 border-b border-white/10 py-3.5"><Check size={17} className="blue" />{feature}</li>)}</ul><div className="mt-5 border border-[#40aaff]/25 bg-[#40aaff]/[0.05] p-4 text-sm text-white/75"><strong className="blue block">Doğrulama notu</strong>Mavi tik, ödemenin site yöneticisi tarafından onaylanmasıyla otomatik olarak hesabına eklenir.</div></div>
      <div className="panel h-fit p-5"><div className="price-switch mb-5 w-full"><button className={plan === "plus_monthly" ? "active" : ""} onClick={() => setPlan("plus_monthly")}>Aylık</button><button className={plan === "plus_yearly" ? "active" : ""} onClick={() => setPlan("plus_yearly")}>Yıllık · 2 ay hediye</button></div><div className="flex items-end gap-2"><strong className="text-4xl tracking-[-0.05em]">{money(price)}</strong><span className="muted mb-1 text-sm">/ {plan === "plus_monthly" ? "ay" : "yıl"}</span></div><p className="mono muted mt-2 text-[11px]">Tek seferlik dönem ödemesi · Otomatik yenileme yok</p><button className="btn-primary mt-6 w-full" onClick={() => create.mutate({ plan })} disabled={create.isPending}><CreditCard size={18} />{create.isPending ? "Sipariş oluşturuluyor…" : user.plan === "plus" ? "Süreyi uzat" : "Ödeme talimatı oluştur"}</button><p className="muted mt-3 text-center text-xs">Kart bilgisi istenmez veya saklanmaz.</p></div>
    </section>

    {created && <section className="mt-8 border border-[#d4ff00]/30 bg-[#d4ff00]/[0.04] p-5"><div className="flex items-start justify-between gap-4"><div><p className="mono lime text-xs">SİPARİŞ OLUŞTU</p><h2 className="mt-1 text-xl font-semibold">{created.referenceCode}</h2></div><span className="text-xl font-semibold">{money(created.amount)}</span></div>{created.payment.iban ? <div className="mt-5 space-y-3 text-sm"><p><span className="muted">Banka:</span> {created.payment.bankName}</p><p><span className="muted">Hesap adı:</span> {created.payment.accountName}</p><div className="flex flex-wrap items-center gap-2"><code className="mono break-all rounded bg-black/30 p-2">{created.payment.iban}</code><button className="icon-btn" onClick={() => copy(created.payment.iban)} aria-label="IBAN kopyala"><Copy size={17} /></button></div><p className="text-white/70">Açıklama alanına <strong className="lime">{created.referenceCode}</strong> yaz. Ardından ödeme bildirimini gönder.</p><button className="btn-primary" onClick={() => { const order = orders.data?.find((item) => item.referenceCode === created.referenceCode); if (order) markSent.mutate({ orderId: order.id }); }} disabled={markSent.isPending}><FileCheck2 size={17} />Ödemeyi yaptım, bildir</button></div> : <p className="mt-4 text-sm text-[#ffd866]">Satıcı banka bilgilerini henüz eklemedi. Siparişin kaydedildi; ödeme bilgileri eklendiğinde bu sayfada görünecek.</p>}</section>}

    <section className="mt-10"><h2 className="mb-4 text-xl font-semibold">Sipariş geçmişin</h2><div className="border-t border-white/10">{orders.data?.map((order) => <article key={order.id} className="border-b border-white/10 py-4"><div className="flex flex-wrap items-center justify-between gap-3"><div><strong className="mono text-sm">{order.referenceCode}</strong><p className="muted mt-1 text-sm">{order.plan === "plus_monthly" ? "Plus Aylık" : "Plus Yıllık"} · {relativeTime(order.createdAt)}</p></div><div className="text-right"><strong className="block">{money(order.amount)}</strong><span className={`badge mt-1 ${orderStatus[order.status].className}`}>{orderStatus[order.status].label}</span></div></div>{order.status === "awaiting_payment" && <button className="btn-secondary mt-3 text-sm" onClick={() => markSent.mutate({ orderId: order.id })}>Ödeme bildirimi gönder</button>}</article>)}{orders.data?.length === 0 && <p className="muted py-7 text-sm">Henüz siparişin yok.</p>}</div></section>
    {user.plan === "plus" && user.planExpiresAt && <p className="mono muted mt-7 flex items-center gap-2 text-xs"><CalendarDays size={15} />Plus bitiş: {new Intl.DateTimeFormat("tr-TR", { dateStyle: "long" }).format(user.planExpiresAt)}</p>}
  </div>;
}

export function ProfileView({ user, onUserChange }: { user: Account; onUserChange: () => void }) {
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(user.name);
  const [handle, setHandle] = useState(user.handle);
  const [bio, setBio] = useState(user.bio ?? "");
  const [gender, setGender] = useState(user.gender);
  const [avatar, setAvatar] = useState(user.avatar ?? "");
  const [avatarKey, setAvatarKey] = useState(user.avatarKey ?? "");
  const [avatarFile, setAvatarFile] = useState<File | null>(null);
  const [avatarPreview, setAvatarPreview] = useState(user.avatar ?? "");
  const feed = trpc.social.feed.useQuery();
  const stats = trpc.social.mySocialStats.useQuery();
  const upload = trpc.storage.uploadImage.useMutation();
  const utils = trpc.useUtils();
  const update = trpc.social.updateProfile.useMutation({
    onSuccess: async () => {
      setEditing(false);
      setAvatarFile(null);
      await Promise.all([utils.account.me.invalidate(), utils.social.feed.invalidate(), utils.social.people.invalidate(), utils.social.mySocialStats.invalidate()]);
      onUserChange();
      toast.success("Profilin güncellendi");
    },
    onError: (error) => toast.error(error.message),
  });
  const ownPosts = feed.data?.filter((post) => post.author.id === user.id) ?? [];

  function selectAvatar(event: ChangeEvent<HTMLInputElement>) {
    const selected = event.target.files?.[0];
    if (!selected) return;
    if (!/^image\/(jpeg|png|webp|gif)$/.test(selected.type)) { toast.error("Galeriden bir görsel seç"); return; }
    if (selected.size > 8 * 1024 * 1024) { toast.error("Profil fotoğrafı en fazla 8 MB olabilir"); return; }
    if (avatarPreview.startsWith("blob:")) URL.revokeObjectURL(avatarPreview);
    setAvatarFile(selected);
    setAvatarKey("");
    setAvatarPreview(URL.createObjectURL(selected));
  }

  async function submit(event: FormEvent) {
    event.preventDefault();
    try {
      let nextAvatarKey = avatarKey || undefined;
      let nextAvatar = avatar;
      if (avatarFile) {
        toast.loading("Profil fotoğrafın yükleniyor…", { id: "avatar-upload" });
        const saved = await upload.mutateAsync({ name: avatarFile.name, contentBase64: await fileToBase64(avatarFile), contentType: avatarFile.type });
        nextAvatarKey = saved.key;
        nextAvatar = avatarPreview;
        toast.dismiss("avatar-upload");
      }
      update.mutate({ name, handle, bio, gender, avatar: nextAvatar, avatarKey: nextAvatarKey });
    } catch (error) {
      toast.dismiss("avatar-upload");
      toast.error(error instanceof Error ? error.message : "Profil fotoğrafı yüklenemedi");
    }
  }

  return <div className="view-enter">
    <div className="checkerband profile-hero relative h-44 overflow-hidden border-b border-white/10 sm:h-56">
      <div className="geometric-field" aria-hidden="true"><i /><i /><i /><i /></div>
      <p className="display-title absolute bottom-5 left-5 max-w-[9ch] text-5xl font-semibold uppercase leading-[0.85] tracking-[-0.08em] text-white/10 sm:text-7xl">Aetheris profil</p>
    </div>
    <section className="px-4 sm:px-7">
      <div className="-mt-16 flex items-end justify-between gap-4">
        <div className="relative">
          <span className="avatar-ring block"><Avatar src={user.avatar} name={user.name} size={112} /></span>
          <label className="icon-btn absolute -bottom-1 -right-1 rounded-full border border-white/15 bg-[#121212] text-[#40aaff]" title="Profil fotoğrafını galeriden değiştir" aria-label="Profil fotoğrafını galeriden değiştir" onClick={() => setEditing(true)}><Camera size={17} /><input type="file" className="hidden" accept="image/jpeg,image/png,image/webp,image/gif" onChange={selectAvatar} /></label>
        </div>
        <button className="btn-secondary mb-2" onClick={() => setEditing(true)}><Pencil size={16} />Profili düzenle</button>
      </div>
      <div className="mt-4">
        <h1 className="flex flex-wrap items-center gap-2 text-3xl font-semibold tracking-[-0.04em]">{user.name}{user.isVerified && <VerifiedBadge size={24} />}</h1>
        <p className="mono muted mt-1 text-sm">@{user.handle}</p>
        <p className="mt-4 max-w-[60ch] text-white/100">{user.bio}</p>
        <div className="mt-5 flex flex-wrap gap-2">
          <span className={`badge ${user.plan === "plus" ? "status-success" : ""}`}><Crown size={13} />{user.plan === "plus" ? "Plus üye" : "Ücretsiz plan"}</span>
          <span className="badge"><CalendarDays size={13} />{new Intl.DateTimeFormat("tr-TR", { month: "long", year: "numeric" }).format(user.createdAt)} tarihinde katıldı</span>
          <span className="badge">{ownPosts.length} gönderi</span>
          <span className="badge status-info">{stats.data?.followerCount ?? 0} takipçi</span>
          <span className="badge status-info">{stats.data?.followingCount ?? 0} takip</span>
          <span className="badge">{stats.data?.storyCount ?? 0} hikâye</span>
          <span className="coin-chip"><Coins size={13} />{user.coinBalance ?? 0} coin</span>
          <span className="coin-chip diamond-chip"><Gem size={13} />{user.diamondBalance ?? 0} elmas</span>
        </div>
      </div>
    </section>
    <section className="mt-7 border-t border-white/10"><h2 className="px-4 py-4 text-lg font-semibold sm:px-7">Gönderiler</h2>{ownPosts.map((post) => <PostCard key={post.id} post={post} />)}{ownPosts.length === 0 && !feed.isLoading && <p className="muted px-7 py-10 text-center">Henüz gönderi paylaşmadın.</p>}</section>
    <Dialog open={editing} onOpenChange={setEditing}>
      <DialogContent className="border-white/10 bg-[#121212] text-white sm:rounded-lg">
        <DialogHeader><DialogTitle>Profili düzenle</DialogTitle><DialogDescription className="text-white/50">Topluluğun seni nasıl göreceğini belirle. Fotoğrafı galerinden seçebilirsin.</DialogDescription></DialogHeader>
        <form onSubmit={submit} className="space-y-4">
          <div className="flex items-center gap-4"><img src={avatarPreview || user.avatar || undefined} alt="Profil fotoğrafı önizlemesi" className="avatar h-20 w-20" /><label className="btn-secondary cursor-pointer"><Camera size={16} />Galeriden fotoğraf seç<input type="file" className="hidden" accept="image/jpeg,image/png,image/webp,image/gif" onChange={selectAvatar} /></label></div>
          <div><label className="field-label" htmlFor="edit-name">Ad soyad</label><input id="edit-name" className="field" value={name} onChange={(e) => setName(e.target.value)} required /></div>
          <div><label className="field-label" htmlFor="edit-handle">Kullanıcı adı</label><input id="edit-handle" className="field" value={handle} onChange={(e) => setHandle(e.target.value)} required /></div>
          <div><label className="field-label" htmlFor="edit-gender">Cinsiyet</label><select id="edit-gender" className="field" value={gender} onChange={(e) => setGender(e.target.value as typeof gender)}><option value="woman">Kadın</option><option value="man">Erkek</option><option value="nonbinary">Non-binary</option><option value="prefer_not_to_say">Belirtmek istemiyorum</option></select></div>
          <div><label className="field-label" htmlFor="edit-bio">Biyografi</label><textarea id="edit-bio" className="field" value={bio} onChange={(e) => setBio(e.target.value)} maxLength={240} /></div>
          <div><label className="field-label" htmlFor="edit-avatar">Mevcut fotoğraf bağlantısı</label><input id="edit-avatar" type="url" className="field" value={avatar} onChange={(e) => setAvatar(e.target.value)} /></div>
          <button className="btn-primary w-full" disabled={update.isPending || upload.isPending}>{update.isPending || upload.isPending ? "Kaydediliyor…" : "Değişiklikleri kaydet"}</button>
        </form>
      </DialogContent>
    </Dialog>
  </div>;
}

export function SettingsView({ user, onUserChange }: { user: Account; onUserChange: () => void }) {
  const utils = trpc.useUtils();
  const [privateAccount, setPrivateAccount] = useState(user.isPrivate);
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const privacy = trpc.social.updatePrivacy.useMutation({ onSuccess: () => { onUserChange(); toast.success("Gizlilik tercihi kaydedildi"); }, onError: (e) => toast.error(e.message) });
  const changePassword = trpc.account.changePassword.useMutation({ onSuccess: () => { setCurrentPassword(""); setNewPassword(""); toast.success("Şifren değiştirildi"); }, onError: (e) => toast.error(e.message) });
  const logout = trpc.account.logout.useMutation({ onSuccess: async () => { await utils.account.me.invalidate(); window.location.reload(); } });
  function togglePrivacy(value: boolean) { setPrivateAccount(value); privacy.mutate({ isPrivate: value }); }
  function submitPassword(event: FormEvent) { event.preventDefault(); changePassword.mutate({ currentPassword, newPassword }); }
  return <div className="view-enter max-w-3xl p-4 sm:p-7"><section><h2 className="flex items-center gap-2 text-xl font-semibold"><Shield size={21} className="blue" />Gizlilik ve erişim</h2><div className="mt-5 flex items-center justify-between gap-4 border-y border-white/10 py-5"><div><strong>Gizli hesap</strong><p className="muted mt-1 text-sm">Profilini ve gönderilerini yalnızca onaylı bağlantıların görsün.</p></div><button role="switch" aria-checked={privateAccount} aria-label="Gizli hesap" className={`relative h-7 w-12 shrink-0 rounded-full transition-colors ${privateAccount ? "bg-[#40aaff]" : "bg-white/15"}`} onClick={() => togglePrivacy(!privateAccount)} disabled={privacy.isPending}><span className={`absolute top-1 h-5 w-5 rounded-full bg-white transition-transform ${privateAccount ? "translate-x-6" : "translate-x-1"}`} /></button></div></section><section className="mt-9"><h2 className="flex items-center gap-2 text-xl font-semibold"><KeyRound size={21} className="blue" />Şifre güvenliği</h2><p className="muted mt-2 text-sm">Yeni şifre en az 8 karakter, bir büyük harf ve bir rakam içermeli.</p><form onSubmit={submitPassword} className="mt-5 space-y-4"><div><label className="field-label" htmlFor="current-pass">Mevcut şifre</label><input id="current-pass" type="password" className="field" value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} required autoComplete="current-password" /></div><div><label className="field-label" htmlFor="new-pass">Yeni şifre</label><input id="new-pass" type="password" className="field" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} required minLength={8} autoComplete="new-password" /></div><button className="btn-primary" disabled={changePassword.isPending}><Lock size={16} />Şifreyi güncelle</button></form></section><section className="mt-9 border-t border-white/10 pt-7"><h2 className="text-xl font-semibold">Oturum</h2><p className="muted mb-4 mt-1 text-sm">{user.email} adresiyle giriş yaptın.</p><button className="btn-danger" onClick={() => logout.mutate()} disabled={logout.isPending}><LogOut size={17} />Bu cihazda oturumu kapat</button></section></div>;
}

export function AdminView() {
  const stats = trpc.commerce.adminStats.useQuery();
  const orders = trpc.commerce.adminOrders.useQuery();
  const payment = trpc.commerce.paymentDetails.useQuery();
  const reelStats = trpc.reels.adminStats.useQuery();
  const [accountName, setAccountName] = useState("");
  const [bankName, setBankName] = useState("");
  const [iban, setIban] = useState("");
  useEffect(() => { if (payment.data) { setAccountName(payment.data.accountName); setBankName(payment.data.bankName); setIban(payment.data.iban); } }, [payment.data]);
  const approve = trpc.commerce.approveOrder.useMutation({ onSuccess: () => { orders.refetch(); stats.refetch(); toast.success("Ödeme onaylandı, Plus ve mavi tik aktif"); } });
  const reject = trpc.commerce.rejectOrder.useMutation({ onSuccess: () => { orders.refetch(); stats.refetch(); toast.success("Sipariş reddedildi"); } });
  const savePayment = trpc.commerce.savePaymentDetails.useMutation({ onSuccess: () => { payment.refetch(); toast.success("Ödeme bilgileri kaydedildi"); }, onError: (e) => toast.error(e.message) });
  function submitPayment(event: FormEvent) { event.preventDefault(); savePayment.mutate({ accountName, bankName, iban }); }
  return <div className="view-enter p-4 sm:p-7"><div className="flex items-center gap-3"><BarChart3 className="blue" size={27} /><div><h1 className="text-2xl font-semibold">Yönetim merkezi</h1><p className="muted text-sm">Satışları, üyelikleri ve ödeme ayarlarını yönet.</p></div></div><div className="stat-row mt-7">{[[stats.data?.approvedRevenue !== undefined ? money(stats.data.approvedRevenue) : "—", "Onaylı ciro"], [stats.data?.pendingOrders ?? "—", "Bekleyen ödeme"], [stats.data?.plusUsers ?? "—", "Plus üye"], [stats.data?.users ?? "—", "Toplam üye"], [stats.data?.verifiedUsers ?? "—", "Mavi tik"], [stats.data?.openTickets ?? "—", "Açık destek"]].map(([value, label]) => <div key={String(label)} className="stat-cell bg-[#151515]"><strong className="block text-2xl">{value}</strong><span className="mono muted text-[10px] uppercase">{label}</span></div>)}</div>
    <section className="mt-9"><h2 className="mb-4 flex items-center gap-2 text-xl font-semibold"><BarChart3 size={20} className="blue" />Reels performansı</h2>{reelStats.data ? <><div className="stat-row">{[[String(reelStats.data.totalViews), "Toplam görüntülenme"], [formatWatch(reelStats.data.totalWatchSeconds), "Toplam izlenme"], [String(reelStats.data.totalLikes), "Reels beğenisi"]].map(([value, label]) => <div key={String(label)} className="stat-cell bg-[#151515]"><strong className="block text-2xl">{value}</strong><span className="mono muted text-[10px] uppercase">{label}</span></div>)}</div>{reelStats.data.perReel.length > 0 && <div className="mt-5 border-t border-white/10">{reelStats.data.perReel.map((reel) => <div key={reel.reelId} className="flex flex-wrap items-center justify-between gap-2 border-b border-white/10 py-3"><div className="min-w-0"><strong className="block truncate text-sm">{reel.title}</strong><span className="mono muted text-[10px]">{reel.author} · {reel.watchers} izleyici</span></div><div className="mono flex items-center gap-4 text-[11px] text-white/70"><span>{reel.views} görüntülenme</span><span>{formatWatch(reel.watchSeconds)}</span></div></div>)}</div>}</> : <p className="muted text-sm">Reels verisi yükleniyor…</p>}</section>
    <section className="mt-9"><h2 className="mb-4 flex items-center gap-2 text-xl font-semibold"><Landmark size={20} className="blue" />Havale / EFT hesabı</h2><form onSubmit={submitPayment} className="grid gap-4 sm:grid-cols-2"><div><label className="field-label" htmlFor="bank-account">Hesap adı</label><input id="bank-account" className="field" value={accountName} onChange={(e) => setAccountName(e.target.value)} required placeholder="Şirket veya hesap sahibi" /></div><div><label className="field-label" htmlFor="bank-name">Banka</label><input id="bank-name" className="field" value={bankName} onChange={(e) => setBankName(e.target.value)} required placeholder="Banka adı" /></div><div className="sm:col-span-2"><label className="field-label" htmlFor="bank-iban">IBAN</label><input id="bank-iban" className="field mono" value={iban} onChange={(e) => setIban(e.target.value)} required minLength={16} placeholder="TR00 0000 0000 0000 0000 0000 00" /></div><button className="btn-primary sm:col-span-2 sm:w-fit" disabled={savePayment.isPending}>Ödeme bilgilerini kaydet</button></form></section>
    <section className="mt-10"><h2 className="mb-4 text-xl font-semibold">Siparişler</h2><div className="border-t border-white/10">{orders.data?.map(({ order, user: buyer }) => <article key={order.id} className="border-b border-white/10 py-4"><div className="flex flex-wrap items-start justify-between gap-3"><div><strong className="mono">{order.referenceCode}</strong><p className="mt-1 text-sm">{buyer.name} · @{buyer.handle}</p><p className="muted text-xs">{order.plan === "plus_monthly" ? "Aylık" : "Yıllık"} · {money(order.amount)} · {relativeTime(order.createdAt)}</p></div><span className={`badge ${orderStatus[order.status].className}`}>{orderStatus[order.status].label}</span></div>{(order.status === "pending_review" || order.status === "awaiting_payment") && <div className="mt-3 flex gap-2"><button className="btn-primary text-sm" onClick={() => approve.mutate({ orderId: order.id })}><BadgeCheck size={16} />Onayla ve Plus ver</button><button className="btn-danger text-sm" onClick={() => reject.mutate({ orderId: order.id })}><XCircle size={16} />Reddet</button></div>}</article>)}{orders.data?.length === 0 && <p className="muted py-8 text-sm">Henüz sipariş yok.</p>}</div></section></div>;
}
