import { useEffect, useRef, useState, type FormEvent } from "react";
import {
  ArrowLeft, Car, Coins, Copy, Crown, Eye, Flower2, Gem, Gift, Heart, Loader2,
  MessageCircle, Music, Radio, Rocket, Send, Signal, Square, Star, Trophy, Users, Coffee,
} from "lucide-react";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { DAILY_COINS_AMOUNT, DAILY_COINS_COOLDOWN_MS, GIFT_CATALOG, LiveCategories, TIP_AMOUNTS, type Gift as GiftDef } from "@contracts/constants";
import { money, relativeTime } from "@/lib/format";
import { trpc } from "@/providers/trpc";
import type { Account, LiveChatMessage, LiveGiftEvent, LiveGiftLeader, LiveListItem, LiveSummary } from "@/types";
import { Avatar, VerifiedBadge } from "./Brand";

const GIFT_ICONS = { Flower2, Heart, Star, Music, Coffee, Trophy, Crown, Car, Rocket, Gem } as const;
type GiftIconName = keyof typeof GIFT_ICONS;

export function giftById(id: string): GiftDef | undefined {
  return GIFT_CATALOG.find((item) => item.id === id);
}

function GiftIcon({ gift, size = 22 }: { gift: GiftDef; size?: number }) {
  const Icon = GIFT_ICONS[gift.icon as GiftIconName] ?? Gift;
  return <Icon size={size} />;
}

const TIER_COLORS = ["#ff6c88", "#ffd866", "#7ee7ff"];

type FlyingGift = { id: number; gift: GiftDef; lane: number; sway: number; rot: number; rise: number; dur: number };
type GiftCombo = { id: number; text: string; color: string };

/** İzleyicinin gördüğü hediye animasyonlarını yönetir: uçuş + kombo rozeti. */
function useGiftEffects() {
  const [flying, setFlying] = useState<FlyingGift[]>([]);
  const [combos, setCombos] = useState<GiftCombo[]>([]);
  const counter = useRef(0);

  function spawn(event: LiveGiftEvent) {
    const gift = giftById(event.giftId);
    if (!gift) return;
    const color = TIER_COLORS[gift.tier - 1];
    const flights = Math.min(event.count, 5);
    const batch = Array.from({ length: flights }, () => {
      counter.current += 1;
      return {
        id: counter.current,
        gift,
        lane: Math.floor(Math.random() * 60),
        sway: Math.round((Math.random() - 0.5) * 180),
        rot: Math.round((Math.random() - 0.5) * 60),
        rise: 150 + Math.round(Math.random() * 120),
        dur: 2200 + Math.round(Math.random() * 800),
      };
    });
    setFlying((prev) => [...prev.slice(-24), ...batch]);
    for (const item of batch) {
      window.setTimeout(() => setFlying((prev) => prev.filter((g) => g.id !== item.id)), item.dur + 300);
    }
    if (event.count > 1 || gift.tier >= 2) {
      counter.current += 1;
      const combo: GiftCombo = {
        id: counter.current,
        text: `${event.sender.name} · ${gift.name}${event.count > 1 ? ` ×${event.count}` : ""}`,
        color,
      };
      setCombos((prev) => [...prev.slice(-3), combo]);
      window.setTimeout(() => setCombos((prev) => prev.filter((c) => c.id !== combo.id)), 1500);
    }
  }

  return { flying, combos, spawn };
}

/* ─── Paylaşılan parçalar ─── */

function Aurora() {
  return (
    <div className="aurora" aria-hidden="true">
      <i /><i /><i />
    </div>
  );
}

export function LiveBadge() {
  return (
    <span className="live-badge">
      <span className="live-dot" />
      CANLI
    </span>
  );
}

function elapsedMinutes(startedAt: Date | string) {
  return Math.max(1, Math.round((Date.now() - new Date(startedAt).getTime()) / 60000));
}

type FloatingHeart = { id: number; lane: number; sway: number; rot: number; color: string };

function useFloatingHearts() {
  const [hearts, setHearts] = useState<FloatingHeart[]>([]);
  const counter = useRef(0);
  function spawn(count: number) {
    const palette = ["#ff6c88", "#40aaff", "#d4ff00"];
    const batch = Array.from({ length: count }, () => {
      counter.current += 1;
      return {
        id: counter.current,
        lane: Math.floor(Math.random() * 52),
        sway: Math.round((Math.random() - 0.5) * 76),
        rot: Math.round((Math.random() - 0.5) * 44),
        color: palette[counter.current % palette.length],
      };
    });
    setHearts((prev) => [...prev.slice(-28), ...batch]);
    for (const heart of batch) {
      window.setTimeout(() => setHearts((prev) => prev.filter((item) => item.id !== heart.id)), 2500);
    }
  }
  return { hearts, spawn };
}

/* ─── Canlı dizini ─── */

export function LiveView({ user, onOpenRoom }: { user: Account; onOpenRoom: (room: { id: number; isHost: boolean }) => void }) {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState<(typeof LiveCategories)[number]>("Sohbet");
  const list = trpc.live.list.useQuery(undefined, { refetchInterval: 15000 });
  const start = trpc.live.start.useMutation({
    onSuccess: (result) => {
      setDialogOpen(false);
      setTitle("");
      list.refetch();
      onOpenRoom({ id: result.id, isHost: true });
      toast.success("Yayın başladı — iyi yayınlar!");
    },
    onError: (error) => toast.error(error.message),
  });

  const myLive = list.data?.live.find((item) => item.host.id === user.id);

  function submitStart(event: FormEvent) {
    event.preventDefault();
    start.mutate({ title, category });
  }

  return (
    <div className="view-enter p-4 sm:p-7">
      <section className="relative overflow-hidden rounded-xl border border-white/10 bg-[#151515] p-6 sm:p-9">
        <Aurora />
        <div className="relative">
          <p className="mono blue text-xs uppercase tracking-[0.15em]">Aetheris Canlı</p>
          <h1 className="mt-3 max-w-[16ch] text-4xl font-semibold leading-[1.02] tracking-[-0.05em]">Perde açık. Sahne senin.</h1>
          <p className="mt-4 max-w-[52ch] text-white/70">
            Topluluğa canlı bağlan; izleyiciler sohbete katılsın, kalpler uçuşsun, destekler anında düşsün.
          </p>
          <div className="mt-6 flex flex-wrap items-center gap-3">
            {myLive ? (
              <button className="btn-primary" onClick={() => onOpenRoom({ id: myLive.id, isHost: true })}>
                <Radio size={17} />
                Devam eden yayınına dön
              </button>
            ) : (
              <button className="btn-primary" onClick={() => setDialogOpen(true)}>
                <Radio size={17} />
                Canlı yayın başlat
              </button>
            )}
            <span className="mono muted text-[11px]">{list.data?.live.length ?? 0} yayın şu an canlı</span>
          </div>
        </div>
      </section>

      <section className="mt-9" aria-label="Canlı yayınlar">
        <h2 className="mb-4 text-xl font-semibold tracking-tight">Şu an canlı</h2>
        {list.isLoading && <div className="grid gap-4 sm:grid-cols-2">{[1, 2].map((item) => <div key={item} className="skeleton h-56 rounded-xl" />)}</div>}
        {list.data?.live.length === 0 && (
          <div className="panel p-10 text-center">
            <Signal className="blue mx-auto mb-4" size={30} />
            <p className="text-lg font-semibold">Şu an sessizlik hâkim.</p>
            <p className="muted mt-1 text-sm">İlk yayını başlatarak sahneyi sen al.</p>
          </div>
        )}
        <div className="stagger grid gap-4 sm:grid-cols-2">
          {list.data?.live.map((item) => <LiveCard key={item.id} item={item} onOpen={() => onOpenRoom({ id: item.id, isHost: item.host.id === user.id })} />)}
        </div>
      </section>

      {Boolean(list.data?.ended.length) && (
        <section className="mt-10" aria-label="Son yayınlar">
          <h2 className="mb-4 text-xl font-semibold tracking-tight">Son yayınlar</h2>
          <div className="border-t border-white/10">
            {list.data?.ended.map((item) => (
              <article key={item.id} className="flex flex-wrap items-center gap-x-5 gap-y-2 border-b border-white/10 py-4">
                <Avatar src={item.host.avatar} name={item.host.name} size={38} />
                <div className="min-w-0 flex-1">
                  <strong className="block truncate text-sm">{item.title}</strong>
                  <span className="mono muted text-[10px]">
                    {item.host.name} · {item.category} · {relativeTime(item.startedAt)}
                  </span>
                </div>
                <div className="mono muted flex items-center gap-4 text-[11px]">
                  <span className="flex items-center gap-1.5"><Users size={13} />{item.peakViewers} zirve</span>
                  <span className="flex items-center gap-1.5"><Heart size={13} />{item.reactionCount}</span>
                  <span className="flex items-center gap-1.5"><MessageCircle size={13} />{item.messageCount}</span>
                </div>
              </article>
            ))}
          </div>
        </section>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="border-white/10 bg-[#121212] text-white sm:rounded-lg">
          <DialogHeader>
            <DialogTitle>Canlı yayın başlat</DialogTitle>
            <DialogDescription className="text-white/50">Başlığını yaz, kategorini seç; yayın anında dizinde görünür.</DialogDescription>
          </DialogHeader>
          <form onSubmit={submitStart} className="space-y-4">
            <div>
              <label htmlFor="live-title" className="field-label">Yayın başlığı</label>
              <input id="live-title" className="field" value={title} onChange={(e) => setTitle(e.target.value)} required minLength={3} maxLength={160} placeholder="Örn. Akşam kodlama seansı" />
            </div>
            <div>
              <label htmlFor="live-category" className="field-label">Kategori</label>
              <select id="live-category" className="field" value={category} onChange={(e) => setCategory(e.target.value as typeof category)}>
                {LiveCategories.map((item) => <option key={item} value={item}>{item}</option>)}
              </select>
            </div>
            <p className="mono muted text-[10px]">Kameran izin verirsen görüntün yayına eklenir; izin vermezsen yayın aurora sahnesiyle sürer.</p>
            <button className="btn-primary w-full" disabled={start.isPending || title.trim().length < 3}>
              <Radio size={17} />
              {start.isPending ? "Yayın açılıyor…" : "Yayına geç"}
            </button>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function LiveCard({ item, onOpen }: { item: LiveListItem; onOpen: () => void }) {
  return (
    <button className="live-card" onClick={onOpen} aria-label={`${item.host.name} adlı yayıncının ${item.title} yayınını izle`}>
      <div className="relative aspect-video bg-black">
        <Aurora />
        <div className="absolute left-3 top-3"><LiveBadge /></div>
        <span className="mono absolute right-3 top-3 flex items-center gap-1.5 rounded bg-black/60 px-2 py-1 text-[10px] text-white">
          <Eye size={12} />
          {item.viewerCount}
        </span>
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="flex h-14 w-14 items-center justify-center rounded-full border border-white/25 bg-black/40 backdrop-blur">
            <Radio size={22} className="text-white" />
          </span>
        </div>
      </div>
      <div className="flex items-start gap-3 p-4">
        <Avatar src={item.host.avatar} name={item.host.name} size={38} />
        <div className="min-w-0">
          <strong className="block truncate text-sm">{item.title}</strong>
          <span className="muted flex items-center gap-1.5 text-xs">
            {item.host.name}
            {item.host.isVerified && <VerifiedBadge size={13} />}
          </span>
          <span className="mono muted mt-1.5 flex items-center gap-2 text-[10px]">
            <span className="badge">{item.category}</span>
            {elapsedMinutes(item.startedAt)} dk'dır canlı
          </span>
        </div>
      </div>
    </button>
  );
}

/* ─── Yayın odası ─── */

export function LiveRoom({ streamId, isHost, user, onExit }: { streamId: number; isHost: boolean; user: Account; onExit: () => void }) {
  const [messages, setMessages] = useState<LiveChatMessage[]>([]);
  const [draft, setDraft] = useState("");
  const [viewerCount, setViewerCount] = useState(0);
  const [ended, setEnded] = useState(false);
  const [cameraState, setCameraState] = useState<"pending" | "on" | "off">("pending");
  const [endConfirm, setEndConfirm] = useState(false);
  const [summary, setSummary] = useState<LiveSummary | null>(null);
  const [tipOpen, setTipOpen] = useState(false);
  const [tipResult, setTipResult] = useState<{ referenceCode: string; amount: number; payment: { accountName: string; bankName: string; iban: string } } | null>(null);
  const [giftOpen, setGiftOpen] = useState(false);
  const [selectedGift, setSelectedGift] = useState<string>(GIFT_CATALOG[0].id);
  const [giftMultiplier, setGiftMultiplier] = useState(1);
  const [coinBalance, setCoinBalance] = useState(user.coinBalance ?? 0);
  const [leaders, setLeaders] = useState<LiveGiftLeader[]>([]);
  const sinceRef = useRef(0);
  const giftSinceRef = useRef(0);
  const videoRef = useRef<HTMLVideoElement>(null);
  const chatScrollRef = useRef<HTMLDivElement>(null);
  const pushBusy = useRef(false);
  const { hearts, spawn } = useFloatingHearts();
  const { flying, combos, spawn: spawnGift } = useGiftEffects();

  const utils = trpc.useUtils();
  const info = trpc.live.get.useQuery({ streamId }, { refetchInterval: 10000 });
  const heartbeat = trpc.live.heartbeat.useMutation();
  const send = trpc.live.sendMessage.useMutation({ onError: (e) => toast.error(e.message) });
  const react = trpc.live.react.useMutation();
  const pushFrame = trpc.live.pushFrame.useMutation();
  const end = trpc.live.end.useMutation({
    onSuccess: (result) => {
      setEndConfirm(false);
      setSummary(result);
      setEnded(true);
      utils.live.list.invalidate();
    },
    onError: (e) => toast.error(e.message),
  });
  const tip = trpc.live.tip.useMutation({ onSuccess: setTipResult, onError: (e) => toast.error(e.message) });
  const sendGift = trpc.live.sendGift.useMutation({
    onSuccess: (result) => {
      setCoinBalance(result.coinBalance);
      const gift = giftById(selectedGift);
      if (gift) {
        spawnGift({
          id: Date.now(),
          giftId: gift.id,
          count: giftMultiplier,
          createdAt: new Date(),
          sender: { id: user.id, name: user.name, handle: user.handle, avatar: user.avatar, isVerified: user.isVerified },
        });
      }
      setGiftOpen(false);
      toast.success(`${giftMultiplier > 1 ? `${giftMultiplier}× ` : ""}${gift?.name ?? "Hediye"} gönderildi · Bakiye: ${result.coinBalance} coin`);
    },
    onError: (e) => toast.error(e.message),
  });
  const claimDaily = trpc.account.claimDailyCoins.useMutation({
    onSuccess: (result) => {
      setCoinBalance(result.coinBalance);
      utils.account.me.invalidate();
      toast.success(`+${result.granted} coin cüzdanına eklendi`);
    },
    onError: (e) => toast.error(e.message),
  });
  const dailyReady = !user.lastDailyCoinsAt || Date.now() - new Date(user.lastDailyCoinsAt).getTime() >= DAILY_COINS_COOLDOWN_MS;
  const markTipSent = trpc.live.markTipSent.useMutation({
    onSuccess: () => {
      setTipResult(null);
      setTipOpen(false);
      toast.success("Destek bildirimin alındı, teşekkürler");
    },
    onError: (e) => toast.error(e.message),
  });
  const frameQuery = trpc.live.frame.useQuery({ streamId }, { enabled: !isHost && !ended, refetchInterval: 1000 });

  // Yayın kapandıysa (başka sekmeden ya da yayıncıdan) izleyiciye yansıt
  useEffect(() => {
    if (info.data?.status === "ended") setEnded(true);
  }, [info.data?.status]);

  // Sohbet + tepki + izleyici sayısı + hediyeler: 2 sn'lik artımlı yoklama
  useEffect(() => {
    let alive = true;
    const poll = async () => {
      try {
        const data = await utils.live.chat.fetch({ streamId, sinceId: sinceRef.current });
        if (!alive) return;
        if (data.messages.length) {
          sinceRef.current = data.messages[data.messages.length - 1].id;
          setMessages((prev) => [...prev, ...data.messages].slice(-200));
        }
        setViewerCount(data.viewerCount);
        if (data.recentReactions > 0) spawn(Math.min(data.recentReactions, 8));
      } catch { /* geçici ağ hatası, bir sonraki turda düzelir */ }
      try {
        const giftData = await utils.live.gifts.fetch({ streamId, sinceId: giftSinceRef.current });
        if (!alive) return;
        if (giftData.events.length) {
          giftSinceRef.current = giftData.events[giftData.events.length - 1].id;
          for (const event of giftData.events.slice(-8)) spawnGift(event);
        }
        setLeaders(giftData.leaderboard);
      } catch { /* hediye turu atlandı */ }
    };
    poll();
    const timer = window.setInterval(poll, 2000);
    return () => { alive = false; window.clearInterval(timer); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [streamId]);

  // İzleyici varlığı (heartbeat)
  useEffect(() => {
    let alive = true;
    const beat = async () => {
      try {
        const result = await heartbeat.mutateAsync({ streamId });
        if (!alive) return;
        setViewerCount(result.viewerCount);
        if (result.status === "ended") setEnded(true);
      } catch { /* yok say */ }
    };
    beat();
    const timer = window.setInterval(beat, 8000);
    return () => { alive = false; window.clearInterval(timer); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [streamId]);

  // Yayıncı kamerası + kare aktarımı (~1 fps JPEG)
  useEffect(() => {
    if (!isHost || ended) return;
    let stream: MediaStream | null = null;
    let timer: number | undefined;
    let cancelled = false;
    if (!navigator.mediaDevices?.getUserMedia) {
      setCameraState("off");
      return;
    }
    navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 360 }, audio: false })
      .then((media) => {
        if (cancelled) { media.getTracks().forEach((track) => track.stop()); return; }
        stream = media;
        if (videoRef.current) videoRef.current.srcObject = media;
        setCameraState("on");
        const canvas = document.createElement("canvas");
        canvas.width = 640;
        canvas.height = 360;
        const context = canvas.getContext("2d");
        timer = window.setInterval(async () => {
          const video = videoRef.current;
          if (!video || !context || pushBusy.current || video.readyState < 2) return;
          context.drawImage(video, 0, 0, 640, 360);
          const data = canvas.toDataURL("image/jpeg", 0.55);
          if (data.length > 1_400_000) return;
          pushBusy.current = true;
          try { await pushFrame.mutateAsync({ streamId, data }); } catch { /* kare atlandı */ } finally { pushBusy.current = false; }
        }, 1000);
      })
      .catch(() => setCameraState("off"));
    return () => {
      cancelled = true;
      if (timer) window.clearInterval(timer);
      stream?.getTracks().forEach((track) => track.stop());
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isHost, streamId, ended]);

  // Sohbet otomatik kaydırma
  useEffect(() => {
    const box = chatScrollRef.current;
    if (box) box.scrollTop = box.scrollHeight;
  }, [messages.length]);

  function submitMessage(event: FormEvent) {
    event.preventDefault();
    if (!draft.trim() || ended) return;
    send.mutate({ streamId, content: draft });
    setDraft("");
  }

  function sendHeart() {
    if (ended) return;
    spawn(1);
    react.mutate({ streamId, count: 1 });
  }

  async function copy(text: string) {
    await navigator.clipboard.writeText(text);
    toast.success("Kopyalandı");
  }

  const host = info.data?.host;
  const frame = !isHost && frameQuery.data?.status === "live" ? frameQuery.data.frame : null;

  return (
    <div className="view-enter flex min-h-[calc(100dvh-150px)] flex-col lg:h-[calc(100dvh-70px)]">
      <header className="flex flex-wrap items-center gap-3 border-b border-white/10 px-4 py-3 sm:px-6">
        <button className="icon-btn" onClick={onExit} aria-label="Canlı dizinine dön"><ArrowLeft size={19} /></button>
        {!ended && <LiveBadge />}
        <div className="min-w-0 flex-1">
          <h1 className="truncate text-[15px] font-semibold">{info.data?.title ?? "Yayın yükleniyor…"}</h1>
          <p className="mono muted flex items-center gap-1.5 text-[10px]">
            {host && <>{host.name}{host.isVerified && <VerifiedBadge size={12} />} · </>}
            {info.data?.category} · {info.data ? `${elapsedMinutes(info.data.startedAt)} dk` : ""}
          </p>
        </div>
        <span className="mono flex items-center gap-1.5 rounded border border-white/10 px-2.5 py-1.5 text-[11px] text-white/80">
          <Eye size={13} />
          {viewerCount}
        </span>
        {isHost && !ended && (
          <button className="btn-danger min-h-[40px] px-3 text-sm" onClick={() => setEndConfirm(true)}>
            <Square size={14} />
            Yayını bitir
          </button>
        )}
      </header>

      <div className="grid min-h-0 flex-1 lg:grid-cols-[minmax(0,1fr)_330px]">
        {/* Sahne */}
        <section className="relative flex min-h-[300px] items-center justify-center overflow-hidden bg-black lg:min-h-0">
          <Aurora />
          {isHost && (
            <video
              ref={videoRef}
              className={`relative h-full w-full -scale-x-100 object-contain ${cameraState === "on" && !ended ? "" : "hidden"}`}
              autoPlay
              playsInline
              muted
              aria-label="Kamera önizlemen"
            />
          )}
          {isHost && cameraState !== "on" && (
            <div className="relative p-8 text-center">
              <Radio className="blue mx-auto mb-4" size={34} />
              <p className="text-lg font-semibold">{cameraState === "pending" ? "Kamera isteniyor…" : "Kamera kapalı"}</p>
              <p className="muted mx-auto mt-2 max-w-[38ch] text-sm">
                {cameraState === "pending"
                  ? "Tarayıcı izin verirse görüntün yayına eklenir."
                  : "İzin verilmedi; yayının aurora sahnesi ve canlı sohbet ile sürüyor."}
              </p>
            </div>
          )}
          {!isHost && !ended && (
            frame ? (
              <img src={frame} alt={`${host?.name ?? "Yayıncı"} canlı yayın görüntüsü`} className="relative h-full w-full object-contain" />
            ) : (
              <div className="relative p-8 text-center">
                <div className="mx-auto mb-5 flex w-fit items-center gap-3">
                  <Avatar src={host?.avatar} name={host?.name ?? "Yayıncı"} size={64} />
                </div>
                <p className="text-lg font-semibold">{host?.name ?? "Yayıncı"} yayında</p>
                <p className="muted mt-2 text-sm">Görüntü bağlanıyor; sohbet şimdiden açık.</p>
              </div>
            )
          )}
          {ended && (
            <div className="absolute inset-0 z-30 flex flex-col items-center justify-center bg-black/80 p-8 text-center backdrop-blur-sm">
              <p className="text-2xl font-semibold tracking-tight">Yayın sona erdi</p>
              <p className="muted mt-2 max-w-[40ch] text-sm">Katıldığın için teşekkürler. Özet yayıncıda; sohbet kaydı aşağıda duruyor.</p>
              <button className="btn-primary mt-6" onClick={onExit}>Canlı dizinine dön</button>
            </div>
          )}
          {/* Uçuşan kalpler */}
          {hearts.map((heart) => (
            <span
              key={heart.id}
              className="float-heart"
              style={{ "--lane": heart.lane, "--sway": `${heart.sway}px`, "--rot": `${heart.rot}deg` } as React.CSSProperties}
            >
              <Heart size={22} fill={heart.color} color={heart.color} />
            </span>
          ))}
          {/* Uçuşan hediyeler + kombo rozetleri */}
          {flying.map((item) => (
            <span
              key={item.id}
              className={`gift-fly gift-tier-${item.gift.tier}`}
              style={{
                right: `calc(8% + ${item.lane}px)`,
                "--sway": `${item.sway}px`,
                "--rot": `${item.rot}deg`,
                "--rise": `${item.rise}px`,
                "--dur": `${item.dur}ms`,
                "--gift-color": TIER_COLORS[item.gift.tier - 1],
              } as React.CSSProperties}
            >
              <span className="gift-burst block text-[#ffd866]"><GiftIcon gift={item.gift} size={item.gift.tier === 3 ? 40 : 28} /></span>
            </span>
          ))}
          {combos.map((combo) => (
            <span key={combo.id} className="gift-combo rounded-full border px-4 py-1.5 text-xs font-semibold" style={{ borderColor: combo.color, color: combo.color, background: "rgb(0 0 0 / 0.55)" }}>
              {combo.text}
            </span>
          ))}
          {/* Hediye liderlik tablosu */}
          {leaders.length > 0 && (
            <div className="absolute left-3 top-3 z-20 space-y-1.5">
              {leaders.map((row, index) => (
                <div key={row.sender.id} className="flex items-center gap-2 rounded-full border border-white/15 bg-black/55 py-1 pl-1 pr-3 backdrop-blur">
                  <span className="mono flex h-6 w-6 items-center justify-center rounded-full text-[10px] font-bold" style={{ background: index === 0 ? "#ffd866" : index === 1 ? "#cfd4dc" : "#d29a5b", color: "#121212" }}>{index + 1}</span>
                  <Avatar src={row.sender.avatar} name={row.sender.name} size={22} />
                  <span className="max-w-[90px] truncate text-[11px]">{row.sender.name}</span>
                  <span className="mono flex items-center gap-1 text-[10px] text-[#ffd866]"><Coins size={10} />{row.coinTotal}</span>
                </div>
              ))}
            </div>
          )}
        </section>

        {/* Sohbet */}
        <aside className="flex min-h-[320px] flex-col border-t border-white/10 lg:min-h-0 lg:border-l lg:border-t-0">
          <p className="mono muted border-b border-white/10 px-4 py-3 text-[10px] uppercase tracking-[0.12em]">Canlı sohbet</p>
          <div ref={chatScrollRef} className="chat-scroll min-h-0 flex-1 space-y-3 overflow-y-auto p-4">
            {messages.length === 0 && <p className="muted py-10 text-center text-sm">Sohbeti başlatan ilk kişi ol.</p>}
            {messages.map((item) =>
              item.kind === "chat" ? (
                <div key={item.id} className="text-sm leading-snug">
                  <span className="blue font-medium">{item.author.name} </span>
                  <span className="text-white/85">{item.content}</span>
                </div>
              ) : item.kind === "tip" ? (
                <div key={item.id} className="rounded-md border border-[#d4ff00]/30 bg-[#d4ff00]/[0.07] px-3 py-2 text-xs text-[#e5ff7a]">
                  <Gift size={13} className="mr-1.5 inline" />
                  {item.content}
                </div>
              ) : item.kind === "gift" ? (
                <div key={item.id} className="rounded-md border border-[#ffd866]/40 bg-gradient-to-r from-[#ffd866]/[0.12] to-transparent px-3 py-2 text-xs text-[#ffe9a3]">
                  <Gift size={13} className="mr-1.5 inline" />
                  {item.content}
                </div>
              ) : (
                <div key={item.id} className="mono muted text-center text-[10px] uppercase tracking-[0.1em]">{item.content}</div>
              ),
            )}
          </div>
          <div className="border-t border-white/10 p-3">
            <form onSubmit={submitMessage} className="flex gap-2">
              <label htmlFor="live-chat-input" className="sr-only">Canlı sohbet mesajı</label>
              <input id="live-chat-input" className="field min-h-[44px]" value={draft} onChange={(e) => setDraft(e.target.value)} maxLength={300} placeholder={ended ? "Yayın sona erdi" : "Sohbete katıl…"} disabled={ended} />
              <button type="button" className="icon-btn bg-white/[0.05] text-[#ff6c88]" onClick={sendHeart} disabled={ended} aria-label="Kalp gönder">
                <Heart size={19} fill="currentColor" />
              </button>
              <button className="btn-primary px-3" disabled={!draft.trim() || send.isPending || ended} aria-label="Mesajı gönder"><Send size={17} /></button>
            </form>
            {!isHost && !ended && (
              <div className="mt-2 grid grid-cols-2 gap-2">
                <button className="btn-primary px-2 text-sm" onClick={() => setGiftOpen(true)}>
                  <Gift size={16} />
                  Hediye gönder
                </button>
                <button className="btn-secondary px-2 text-sm" onClick={() => { setTipResult(null); setTipOpen(true); }}>
                  <Coins size={16} />
                  Destek ol
                </button>
              </div>
            )}
            {isHost && (
              <p className="mono muted mt-2 flex items-center justify-center gap-1.5 text-[10px]">
                <Gem size={11} className="text-[#7ee7ff]" />
                {user.diamondBalance ?? 0} elmas · hediyelerin yarısı elmas olarak hesabına işlenir
              </p>
            )}
          </div>
        </aside>
      </div>

      {/* Yayın bitirme onayı */}
      <Dialog open={endConfirm} onOpenChange={setEndConfirm}>
        <DialogContent className="border-white/10 bg-[#121212] text-white sm:rounded-lg">
          <DialogHeader>
            <DialogTitle>Yayın bitirilsin mi?</DialogTitle>
            <DialogDescription className="text-white/50">Sohbet kapanır, yayın özeti oluşturulur. Bu işlem geri alınamaz.</DialogDescription>
          </DialogHeader>
          <div className="flex gap-3">
            <button className="btn-ghost flex-1" onClick={() => setEndConfirm(false)}>Vazgeç</button>
            <button className="btn-danger flex-1" onClick={() => end.mutate({ streamId })} disabled={end.isPending}>
              {end.isPending ? "Kapatılıyor…" : "Evet, bitir"}
            </button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Yayın özeti */}
      <Dialog open={Boolean(summary)} onOpenChange={(open) => { if (!open) onExit(); }}>
        <DialogContent className="checkerband border-white/10 bg-[#121212] text-white sm:rounded-lg">
          <DialogHeader>
            <DialogTitle>Yayın özeti</DialogTitle>
            <DialogDescription className="text-white/50">Güzel işti. İşte bu yayının karnesi.</DialogDescription>
          </DialogHeader>
          {summary && (
            <div className="stat-row">
              <div className="stat-cell"><span className="mono muted text-[10px] uppercase">Süre</span><strong className="mt-1 block text-2xl">{summary.minutes} dk</strong></div>
              <div className="stat-cell"><span className="mono muted text-[10px] uppercase">Zirve izleyici</span><strong className="mt-1 block text-2xl">{summary.peakViewers}</strong></div>
              <div className="stat-cell"><span className="mono muted text-[10px] uppercase">Mesaj</span><strong className="mt-1 block text-2xl">{summary.messageCount}</strong></div>
              <div className="stat-cell"><span className="mono muted text-[10px] uppercase">Kalp</span><strong className="mt-1 block text-2xl">{summary.reactionCount}</strong></div>
              <div className="stat-cell col-span-2"><span className="mono muted text-[10px] uppercase">Destek toplamı</span><strong className="lime mt-1 block text-2xl">{money(summary.tipTotal)}</strong></div>
            </div>
          )}
          <button className="btn-primary mt-5 w-full" onClick={onExit}>Canlı dizinine dön</button>
        </DialogContent>
      </Dialog>

      {/* Hediye paneli */}
      <Dialog open={giftOpen} onOpenChange={setGiftOpen}>
        <DialogContent className="checkerband max-w-lg border-white/10 bg-[#121212] text-white sm:rounded-lg">
          <DialogHeader>
            <DialogTitle>Hediye gönder</DialogTitle>
            <DialogDescription className="text-white/50">
              Coin bakiyenle yayıncıyı kutla; hediyen yayında uçuşur, yayıncı elmas kazanır.
            </DialogDescription>
          </DialogHeader>
          <div className="flex items-center justify-between gap-2">
            <span className="coin-chip"><Coins size={14} />{coinBalance} coin</span>
            {dailyReady ? (
              <button className="coin-chip cursor-pointer" onClick={() => claimDaily.mutate()} disabled={claimDaily.isPending}>
                {claimDaily.isPending ? <Loader2 size={13} className="animate-spin" /> : <Coins size={13} />}
                Günlük +{DAILY_COINS_AMOUNT} coin al
              </button>
            ) : (
              <span className="coin-chip diamond-chip"><Gem size={13} />{user.diamondBalance ?? 0} elmasın var</span>
            )}
          </div>
          <div className="gift-panel-grid" role="listbox" aria-label="Hediye seç">
            {GIFT_CATALOG.map((gift) => {
              const affordable = coinBalance >= gift.coinCost * giftMultiplier;
              return (
                <button
                  key={gift.id}
                  role="option"
                  aria-selected={selectedGift === gift.id}
                  className={`gift-cell ${selectedGift === gift.id ? "selected" : ""}`}
                  style={{ color: TIER_COLORS[gift.tier - 1] }}
                  onClick={() => setSelectedGift(gift.id)}
                  disabled={!affordable}
                >
                  <GiftIcon gift={gift} size={26} />
                  <strong className="text-[11px] font-semibold text-white">{gift.name}</strong>
                  <span className="mono flex items-center gap-1 text-[10px] text-[#ffd866]"><Coins size={10} />{gift.coinCost}</span>
                </button>
              );
            })}
          </div>
          <div className="flex items-center gap-2">
            <span className="mono muted text-[10px] uppercase tracking-wider">Adet</span>
            {[1, 5, 10].map((n) => (
              <button key={n} className={`style-chip ${giftMultiplier === n ? "active" : ""}`} onClick={() => setGiftMultiplier(n)}>
                {n > 1 ? `×${n}` : "1"}
              </button>
            ))}
            <span className="mono muted ml-auto text-[11px]">
              Toplam: {(() => { const g = giftById(selectedGift); return g ? g.coinCost * giftMultiplier : 0; })()} coin
            </span>
          </div>
          <button
            className="btn-primary w-full"
            disabled={sendGift.isPending}
            onClick={() => sendGift.mutate({ streamId, giftId: selectedGift, count: giftMultiplier })}
          >
            {sendGift.isPending ? "Gönderiliyor…" : "Hediyeyi gönder"}
            <Gift size={17} />
          </button>
        </DialogContent>
      </Dialog>

      {/* Destek (tip) */}
      <Dialog open={tipOpen} onOpenChange={setTipOpen}>
        <DialogContent className="border-white/10 bg-[#121212] text-white sm:rounded-lg">
          <DialogHeader>
            <DialogTitle>Yayıncıya destek ol</DialogTitle>
            <DialogDescription className="text-white/50">
              Tutarı seç; Havale/EFT talimatı oluşturulur. Desteğin yayın sohbetinde duyurulur.
            </DialogDescription>
          </DialogHeader>
          {!tipResult ? (
            <div className="grid grid-cols-2 gap-3">
              {TIP_AMOUNTS.map((amount) => (
                <button key={amount} className="panel min-h-[64px] text-lg font-semibold transition-colors hover:border-[#40aaff]" onClick={() => tip.mutate({ streamId, amount })} disabled={tip.isPending}>
                  {money(amount)}
                </button>
              ))}
            </div>
          ) : !tipResult.payment.iban ? (
            <div className="space-y-4">
              <p className="rounded-md border border-[#ffd866]/30 bg-[#ffd866]/[0.06] p-4 text-sm text-[#ffd866]">
                Yayıncı banka bilgilerini henüz eklemedi. Destek talebin <strong>{tipResult.referenceCode}</strong> koduyla kaydedildi; ödeme bilgileri eklendiğinde bildirimle haber verilecek.
              </p>
              <button className="btn-secondary w-full" onClick={() => { setTipResult(null); setTipOpen(false); }}>Tamam</button>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="panel space-y-2 p-4 text-sm">
                <p className="flex items-center justify-between gap-3"><span className="muted">Tutar</span><strong>{money(tipResult.amount)}</strong></p>
                <p className="flex items-center justify-between gap-3"><span className="muted">Banka</span><strong>{tipResult.payment.bankName || "—"}</strong></p>
                <p className="flex items-center justify-between gap-3"><span className="muted">Alıcı</span><strong>{tipResult.payment.accountName || "—"}</strong></p>
                <p className="flex items-center justify-between gap-3">
                  <span className="muted">IBAN</span>
                  <button className="mono flex items-center gap-1.5 text-xs text-[#40aaff]" onClick={() => copy(tipResult.payment.iban)}>{tipResult.payment.iban || "—"}<Copy size={13} /></button>
                </p>
                <p className="flex items-center justify-between gap-3">
                  <span className="muted">Açıklama kodu</span>
                  <button className="mono flex items-center gap-1.5 text-xs text-[#40aaff]" onClick={() => copy(tipResult.referenceCode)}>{tipResult.referenceCode}<Copy size={13} /></button>
                </p>
              </div>
              <p className="mono muted text-[10px]">Havale açıklamasına kodu yazmayı unutma; destek, yönetici onayıyla yayıncıya geçer.</p>
              <button className="btn-primary w-full" onClick={() => markTipSent.mutate({ referenceCode: tipResult.referenceCode })} disabled={markTipSent.isPending}>
                {markTipSent.isPending ? "Bildiriliyor…" : "Ödemeyi yaptım, bildir"}
              </button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
