import { useRef, useState, type ChangeEvent, type FormEvent } from "react";
import { Film, Hash, ImagePlus, Plus, Radio, Send, Sparkles, Type, X } from "lucide-react";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { TEXT_STYLES } from "@contracts/constants";
import { relativeTime } from "@/lib/format";
import { trpc } from "@/providers/trpc";
import type { Account, Story } from "@/types";
import { Avatar, VerifiedBadge } from "./Brand";
import PostCard, { StyledText } from "./PostCard";
import { ReportButton } from "./SocialActions";

function fileToBase64(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result).split(",")[1]);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

export default function FeedView({ user, onOpenLive }: { user: Account; onOpenLive: () => void }) {
  const [content, setContent] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [video, setVideo] = useState<File | null>(null);
  const [preview, setPreview] = useState("");
  const [textStyle, setTextStyle] = useState<string | null>(null);
  const [stylePickerOpen, setStylePickerOpen] = useState(false);
  const [storyDialog, setStoryDialog] = useState(false);
  const [storyText, setStoryText] = useState("");
  const [storyFile, setStoryFile] = useState<File | null>(null);
  const [storyPreview, setStoryPreview] = useState("");
  const [activeStory, setActiveStory] = useState<Story | null>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const utils = trpc.useUtils();
  const feed = trpc.social.feed.useQuery(undefined, { refetchInterval: 15000 });
  const stories = trpc.social.stories.useQuery(undefined, { refetchInterval: 30000 });
  const liveList = trpc.live.list.useQuery(undefined, { refetchInterval: 20000 });
  const upload = trpc.storage.uploadImage.useMutation();
  const uploadVideo = trpc.storage.uploadVideo.useMutation();
  const create = trpc.social.createPost.useMutation({
    onSuccess: () => {
      setContent("");
      setFile(null);
      setVideo(null);
      setPreview("");
      setTextStyle(null);
      setStylePickerOpen(false);
      utils.social.feed.invalidate();
      toast.success("Gönderin akışta");
    },
    onError: (error) => toast.error(error.message),
  });
  const createStory = trpc.social.createStory.useMutation({
    onSuccess: async () => {
      setStoryDialog(false);
      setStoryText("");
      setStoryFile(null);
      setStoryPreview("");
      await utils.social.stories.invalidate();
      toast.success("Hikâyen 24 saat boyunca yayında");
    },
    onError: (error) => toast.error(error.message),
  });
  const viewStory = trpc.social.viewStory.useMutation({ onSuccess: () => utils.social.stories.invalidate() });
  const maxLength = user.plan === "plus" ? 1200 : 500;
  const mediaBusy = upload.isPending || uploadVideo.isPending || create.isPending;
  const storyBusy = upload.isPending || createStory.isPending;
  const storyAuthors = stories.data ? Object.values(stories.data.reduce<Record<number, Story>>((acc, story) => {
    if (!acc[story.author.id]) acc[story.author.id] = story;
    return acc;
  }, {})) : [];

  function selectFile(event: ChangeEvent<HTMLInputElement>) {
    const selected = event.target.files?.[0];
    if (!selected) return;
    if (selected.size > 8 * 1024 * 1024) { toast.error("Görsel en fazla 8 MB olabilir"); return; }
    setFile(selected);
    setVideo(null);
    setPreview(URL.createObjectURL(selected));
  }

  function selectVideo(event: ChangeEvent<HTMLInputElement>) {
    const selected = event.target.files?.[0];
    if (!selected) return;
    if (selected.size > 40 * 1024 * 1024) { toast.error("Video en fazla 40 MB olabilir"); return; }
    setVideo(selected);
    setFile(null);
    setPreview(URL.createObjectURL(selected));
  }

  function selectStoryFile(event: ChangeEvent<HTMLInputElement>) {
    const selected = event.target.files?.[0];
    if (!selected) return;
    if (selected.size > 8 * 1024 * 1024) { toast.error("Hikâye görseli en fazla 8 MB olabilir"); return; }
    if (storyPreview) URL.revokeObjectURL(storyPreview);
    setStoryFile(selected);
    setStoryPreview(URL.createObjectURL(selected));
  }

  function clearMedia() {
    if (preview) URL.revokeObjectURL(preview);
    setFile(null);
    setVideo(null);
    setPreview("");
  }

  async function submit(event: FormEvent) {
    event.preventDefault();
    if (!content.trim()) { toast.error("Önce birkaç satır yaz"); return; }
    try {
      let imageKey: string | undefined;
      let videoKey: string | undefined;
      if (file) {
        toast.loading("Görsel güvenli depoya yükleniyor…", { id: "upload" });
        const saved = await upload.mutateAsync({ name: file.name, contentBase64: await fileToBase64(file), contentType: file.type });
        imageKey = saved.key;
        toast.dismiss("upload");
      }
      if (video) {
        toast.loading("Video güvenli depoya yükleniyor…", { id: "upload" });
        const saved = await uploadVideo.mutateAsync({ name: video.name, contentBase64: await fileToBase64(video), contentType: video.type === "video/webm" ? "video/webm" : "video/mp4" });
        videoKey = saved.key;
        toast.dismiss("upload");
      }
      create.mutate({ content, imageKey, videoKey, textStyle: textStyle ?? undefined });
    } catch (error) {
      toast.dismiss("upload");
      toast.error(error instanceof Error ? error.message : "Medya yüklenemedi");
    }
  }

  async function submitStory(event: FormEvent) {
    event.preventDefault();
    if (!storyText.trim() && !storyFile) { toast.error("Hikâye için kısa bir not ya da görsel ekle"); return; }
    try {
      let imageKey: string | undefined;
      if (storyFile) {
        toast.loading("Hikâye görseli yükleniyor…", { id: "story-upload" });
        const saved = await upload.mutateAsync({ name: storyFile.name, contentBase64: await fileToBase64(storyFile), contentType: storyFile.type });
        imageKey = saved.key;
        toast.dismiss("story-upload");
      }
      createStory.mutate({ content: storyText.trim() || undefined, imageKey });
    } catch (error) {
      toast.dismiss("story-upload");
      toast.error(error instanceof Error ? error.message : "Hikâye yüklenemedi");
    }
  }

  function openStory(story: Story) {
    setActiveStory(story);
    if (!story.seen) viewStory.mutate({ storyId: story.id });
  }

  return (
    <div className="view-enter">
      {Boolean(liveList.data?.live.length) && (
        <button className="marquee flex w-full items-center gap-3 border-b border-[#f00007]/25 bg-[#f00007]/[0.06] py-2.5 text-left" onClick={onOpenLive} aria-label="Canlı yayınlara git">
          <span className="live-badge ml-4 shrink-0"><span className="live-dot" />CANLI</span>
          <span className="marquee-track mono text-[11px] text-white/80">
            {[0, 1].map((copy) => (
              <span key={copy} className="flex items-center gap-14" aria-hidden={copy === 1}>
                {liveList.data?.live.map((item) => (
                  <span key={`${copy}-${item.id}`} className="flex items-center gap-2">
                    <Radio size={12} className="text-[#ff6c88]" />
                    {item.host.name}: {item.title} · {item.viewerCount} izleyici
                  </span>
                ))}
              </span>
            ))}
          </span>
        </button>
      )}

      <section className="border-b border-white/10 px-4 py-5 sm:px-7" aria-label="Hikâyeler">
        <div className="flex items-center gap-4 overflow-x-auto pb-1">
          <button className="story-add group" onClick={() => setStoryDialog(true)}><span><Plus size={20} /></span><strong>Hikâye ekle</strong></button>
          {storyAuthors.map((story) => (
            <button key={story.author.id} className={`story-bubble ${story.seen ? "seen" : ""}`} onClick={() => openStory(story)}>
              <span className="story-ring"><Avatar src={story.author.avatar} name={story.author.name} size={54} /></span>
              <strong>{story.author.name.split(" ")[0]}</strong>
            </button>
          ))}
        </div>
      </section>

      <section className="composer border-b border-white/10 px-4 py-6 sm:px-7">
        <div className="geometric-strip" aria-hidden="true"><i /><i /><i /><i /></div>
        <form onSubmit={submit}>
          <div className="relative flex gap-3.5"><Avatar src={user.avatar} name={user.name} size={46} /><div className="min-w-0 flex-1"><label htmlFor="new-post" className="sr-only">Yeni gönderi</label><textarea ref={inputRef} id="new-post" className="field min-h-[108px] border-0 bg-transparent px-0 text-lg focus:bg-transparent" value={content} onChange={(e) => setContent(e.target.value)} maxLength={maxLength} placeholder="Topluluğunla ne paylaşmak istersin?" /></div><Sparkles className="composer-sparkle" size={22} aria-hidden="true" /></div>
          {preview && (
            <div className="relative mt-4 overflow-hidden rounded-lg border border-white/10">
              {video ? (
                <video src={preview} className="max-h-80 w-full bg-black object-contain" muted playsInline aria-label="Yüklenecek video önizlemesi" />
              ) : (
                <img src={preview} alt="Yüklenecek görsel önizlemesi" className="max-h-80 w-full object-cover" />
              )}
              <button type="button" className="icon-btn absolute right-2 top-2 bg-black/70 text-white" onClick={clearMedia} aria-label="Medyayı kaldır"><X size={18} /></button>
              {video && <span className="mono absolute bottom-2 left-2 flex items-center gap-1.5 rounded bg-black/70 px-2 py-1 text-[10px] text-white"><Film size={11} />Video eklendi</span>}
            </div>
          )}
          {stylePickerOpen && (
            <div className="mt-4 rounded-lg border border-white/10 bg-black/30 p-3">
              <p className="mono muted mb-2.5 text-[10px] uppercase tracking-[0.12em]">Hareketli yazı stili</p>
              <div className="flex flex-wrap items-center gap-2">
                <button type="button" className={`style-chip ${textStyle === null ? "active" : ""}`} onClick={() => setTextStyle(null)}>Sade</button>
                {TEXT_STYLES.map((style) => (
                  <button key={style.id} type="button" className={`style-chip ${textStyle === style.id ? "active" : ""}`} onClick={() => setTextStyle(style.id)}>{style.name}</button>
                ))}
              </div>
              {content.trim() && (
                <p className="mt-3 whitespace-pre-wrap break-words border-t border-white/10 pt-3 text-[16px] leading-[1.65]">
                  <StyledText content={content} styleId={textStyle} />
                </p>
              )}
            </div>
          )}
          <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-white/10 pt-4">
            <div className="flex items-center gap-1"><label className="icon-btn cursor-pointer text-[#40aaff]" title="Görsel ekle"><ImagePlus size={20} /><input type="file" className="hidden" accept="image/jpeg,image/png,image/webp,image/gif" onChange={selectFile} /></label><label className="icon-btn cursor-pointer text-[#40aaff]" title="Video ekle"><Film size={20} /><input type="file" className="hidden" accept="video/mp4,video/webm" onChange={selectVideo} /></label><button type="button" className={`icon-btn ${stylePickerOpen || textStyle ? "text-[#d4ff00]" : "text-[#40aaff]"}`} onClick={() => setStylePickerOpen((open) => !open)} aria-label="Hareketli yazı stili seç" aria-pressed={stylePickerOpen}><Type size={20} /></button><button type="button" className="icon-btn text-[#40aaff]" onClick={() => { setContent((value) => `${value}${value ? " " : ""}#Aetheris `); inputRef.current?.focus(); }} aria-label="Etiket ekle"><Hash size={20} /></button><span className={`mono ml-2 text-[10px] ${content.length > maxLength * 0.9 ? "text-[#ffd866]" : "muted"}`}>{content.length}/{maxLength}</span></div>
            <button className="btn-primary" disabled={!content.trim() || mediaBusy}>{mediaBusy ? "Paylaşılıyor…" : "Paylaş"}<Send size={17} /></button>
          </div>
          {user.plan === "free" && <p className="mono muted mt-3 text-[10px]">Plus ile 1.200 karaktere kadar yazabilirsin.</p>}
        </form>
      </section>

      <section aria-label="Gönderi akışı">
        {feed.isLoading && <div className="space-y-5 p-7">{[1, 2, 3].map((item) => <div key={item} className="skeleton h-36 rounded-lg" />)}</div>}
        {feed.isError && <div className="p-8 text-center"><p className="text-red-200">Akış yüklenemedi.</p><button className="btn-secondary mt-4" onClick={() => feed.refetch()}>Tekrar dene</button></div>}
        <div className="stagger">{feed.data?.map((post) => <PostCard key={post.id} post={post} />)}</div>
        {feed.data?.length === 0 && <div className="p-12 text-center"><p className="text-xl font-semibold">Akış henüz sessiz.</p><p className="muted mt-2">İlk gönderiyi paylaşarak sohbeti başlat.</p></div>}
      </section>

      <Dialog open={storyDialog} onOpenChange={setStoryDialog}>
        <DialogContent className="border-white/10 bg-[#121212] text-white sm:rounded-lg">
          <DialogHeader><DialogTitle>Hikâye paylaş</DialogTitle><DialogDescription className="text-white/50">24 saat görünür olacak kısa bir an bırak. Görsel galerinden seçebilirsin.</DialogDescription></DialogHeader>
          <form onSubmit={submitStory} className="space-y-4">
            {storyPreview && <div className="relative overflow-hidden rounded-lg border border-white/10"><img src={storyPreview} alt="Hikâye önizlemesi" className="max-h-72 w-full object-cover" /><button type="button" className="icon-btn absolute right-2 top-2 bg-black/70 text-white" onClick={() => { if (storyPreview) URL.revokeObjectURL(storyPreview); setStoryFile(null); setStoryPreview(""); }} aria-label="Hikâye görselini kaldır"><X size={18} /></button></div>}
            <div><label className="field-label" htmlFor="story-text">Kısa not</label><textarea id="story-text" className="field" value={storyText} onChange={(event) => setStoryText(event.target.value)} maxLength={220} placeholder="Bugünün notu…" /></div>
            <label className="btn-secondary cursor-pointer"><ImagePlus size={17} />Galeriden görsel seç<input type="file" className="hidden" accept="image/jpeg,image/png,image/webp,image/gif" onChange={selectStoryFile} /></label>
            <button className="btn-primary w-full" disabled={storyBusy || (!storyText.trim() && !storyFile)}>{storyBusy ? "Yayınlanıyor…" : "Hikâyeyi yayınla"}</button>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={Boolean(activeStory)} onOpenChange={(open) => !open && setActiveStory(null)}>
        <DialogContent className="story-viewer overflow-hidden border-white/10 bg-[#101010] p-0 text-white sm:rounded-2xl">
          {activeStory && (
            <div className="relative min-h-[72dvh] sm:min-h-[640px]">
              {activeStory.imageUrl ? <img src={activeStory.imageUrl} alt="Hikâye görseli" className="absolute inset-0 h-full w-full object-cover" /> : <div className="checkerband absolute inset-0" />}
              <div className="absolute inset-x-0 top-0 h-1 bg-white/20"><span key={activeStory.id} className="story-progress block h-full bg-[#40aaff]" /></div>
              <div className="absolute inset-x-0 top-0 flex items-center justify-between bg-gradient-to-b from-black/70 to-transparent p-4">
                <div className="flex items-center gap-3"><Avatar src={activeStory.author.avatar} name={activeStory.author.name} size={40} /><div><DialogTitle className="flex items-center gap-2 text-base">{activeStory.author.name}{activeStory.author.isVerified && <VerifiedBadge size={16} />}</DialogTitle><DialogDescription className="mono text-white/60">@{activeStory.author.handle} · {relativeTime(activeStory.createdAt)} · {activeStory.viewCount} görüntülenme</DialogDescription></div></div>
                <div className="flex items-center gap-1"><ReportButton targetType="story" targetId={activeStory.id} title={`@${activeStory.author.handle} hikâyesi`} /><button className="icon-btn" onClick={() => setActiveStory(null)} aria-label="Hikâyeyi kapat"><X size={20} /></button></div>
              </div>
              {activeStory.content && <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 via-black/35 to-transparent p-6 pt-20"><p className="max-w-[28ch] text-3xl font-semibold leading-tight tracking-[-0.04em]">{activeStory.content}</p></div>}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
