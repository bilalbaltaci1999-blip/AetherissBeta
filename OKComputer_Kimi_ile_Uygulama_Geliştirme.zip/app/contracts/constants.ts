export const Session = {
  cookieName: "kimi_sid",
  maxAgeMs: 365 * 24 * 60 * 60 * 1000,
} as const;

export const ErrorMessages = {
  unauthenticated: "Authentication required",
  insufficientRole: "Insufficient permissions",
} as const;

export const Paths = {
  login: "/login",
  oauthCallback: "/api/oauth/callback",
} as const;

export const LiveCategories = ["Sohbet", "Teknoloji", "Tasarım", "Müzik", "Oyun", "Eğitim"] as const;
export type LiveCategory = (typeof LiveCategories)[number];

export const TIP_AMOUNTS = [2500, 5000, 10000, 25000] as const;

/* ─── Sanal ekonomi: Aetheris Coins & Diamonds ─── */
export const COIN_START_BALANCE = 2000;
export const DAILY_COINS_AMOUNT = 500;
export const DAILY_COINS_COOLDOWN_MS = 20 * 60 * 60 * 1000; // 20 saatte bir
export const DIAMOND_RATE = 0.5; // yayıncı, hediye coin'inin yarısını elmas olarak alır

export type Gift = {
  id: string;
  name: string;
  icon: string; // lucide ikon adı
  coinCost: number;
  tier: 1 | 2 | 3; // animasyon görkemi
};

export const GIFT_CATALOG: Gift[] = [
  { id: "gul", name: "Gül", icon: "Flower2", coinCost: 5, tier: 1 },
  { id: "kalp", name: "Kalp", icon: "Heart", coinCost: 10, tier: 1 },
  { id: "yildiz", name: "Yıldız", icon: "Star", coinCost: 20, tier: 1 },
  { id: "nota", name: "Nota", icon: "Music", coinCost: 30, tier: 1 },
  { id: "kahve", name: "Kahve", icon: "Coffee", coinCost: 40, tier: 1 },
  { id: "kupa", name: "Kupa", icon: "Trophy", coinCost: 100, tier: 2 },
  { id: "tac", name: "Taç", icon: "Crown", coinCost: 250, tier: 2 },
  { id: "araba", name: "Araba", icon: "Car", coinCost: 500, tier: 2 },
  { id: "roket", name: "Roket", icon: "Rocket", coinCost: 1000, tier: 3 },
  { id: "elmas", name: "Elmas", icon: "Gem", coinCost: 2500, tier: 3 },
];

/* ─── Hareketli yazı stilleri (gönderi metni animasyonları) ─── */
export type TextStyle = { id: string; name: string; className: string };

export const TEXT_STYLES: TextStyle[] = [
  { id: "neon", name: "Neon", className: "txt-neon" },
  { id: "daktilo", name: "Daktilo", className: "txt-daktilo" },
  { id: "glitch", name: "Glitch", className: "txt-glitch" },
  { id: "dalga", name: "Dalga", className: "txt-dalga" },
  { id: "patlama", name: "Patlama", className: "txt-patlama" },
];

export type Reel = {
  id: string;
  title: string;
  author: string;
  handle: string;
  category: string;
  video: string;
  poster: string;
  durationSec: number;
};

export const Reels: Reel[] = [
  {
    id: "sehir-ritmi",
    title: "Şehrin ritmini kaydetmek",
    author: "Selin Yazıcı",
    handle: "selinyazici",
    category: "Şehir",
    video: "/reels/sehir-ritmi.mp4",
    poster: "/reels/sehir-ritmi.webp",
    durationSec: 6,
  },
  {
    id: "isik-hareket",
    title: "Işık, hareket ve yeni fikirler",
    author: "Emre Keskin",
    handle: "emrekeskin",
    category: "Deneme",
    video: "/reels/isik-hareket.mp4",
    poster: "/reels/isik-hareket.webp",
    durationSec: 6,
  },
  {
    id: "gece-sokagi",
    title: "Gece sokağı: tersten bir yürüyüş",
    author: "Selin Yazıcı",
    handle: "selinyazici",
    category: "Şehir",
    video: "/reels/gece-sokagi.mp4",
    poster: "/reels/gece-sokagi.webp",
    durationSec: 6,
  },
  {
    id: "hiz-cizgisi",
    title: "Hız çizgisi: ışığın ivmelen hâli",
    author: "Emre Keskin",
    handle: "emrekeskin",
    category: "Deneme",
    video: "/reels/hiz-cizgisi.mp4",
    poster: "/reels/hiz-cizgisi.webp",
    durationSec: 3,
  },
  {
    id: "puslu-vizor",
    title: "Puslu vizör: yavaşlayan şehir",
    author: "Deniz Aksoy",
    handle: "demo",
    category: "Atmosfer",
    video: "/reels/puslu-vizor.mp4",
    poster: "/reels/puslu-vizor.webp",
    durationSec: 8,
  },
  {
    id: "ayna",
    title: "Ayna: hareketin yansıması",
    author: "Deniz Aksoy",
    handle: "demo",
    category: "Deneme",
    video: "/reels/ayna.mp4",
    poster: "/reels/ayna.webp",
    durationSec: 6,
  },
];
