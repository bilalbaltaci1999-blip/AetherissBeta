import {
  bigint,
  boolean,
  int,
  mediumtext,
  mysqlEnum,
  mysqlTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }).notNull().unique(),
  handle: varchar("handle", { length: 80 }).unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }).unique(),
  passwordHash: varchar("passwordHash", { length: 255 }),
  avatar: text("avatar"),
  avatarKey: text("avatarKey"),
  gender: mysqlEnum("gender", ["woman", "man", "nonbinary", "prefer_not_to_say"]).default("prefer_not_to_say").notNull(),
  bio: text("bio"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  isVerified: boolean("isVerified").default(false).notNull(),
  isPrivate: boolean("isPrivate").default(false).notNull(),
  plan: mysqlEnum("plan", ["free", "plus"]).default("free").notNull(),
  planExpiresAt: timestamp("planExpiresAt"),
  coinBalance: int("coinBalance").default(2000).notNull(),
  diamondBalance: int("diamondBalance").default(0).notNull(),
  lastDailyCoinsAt: timestamp("lastDailyCoinsAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
});

export const sessions = mysqlTable("sessions", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true })
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  tokenHash: varchar("tokenHash", { length: 64 }).notNull().unique(),
  expiresAt: timestamp("expiresAt").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const passwordResetTokens = mysqlTable("password_reset_tokens", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true })
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  tokenHash: varchar("tokenHash", { length: 64 }).notNull().unique(),
  expiresAt: timestamp("expiresAt").notNull(),
  usedAt: timestamp("usedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const posts = mysqlTable("posts", {
  id: serial("id").primaryKey(),
  authorId: bigint("authorId", { mode: "number", unsigned: true })
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  content: text("content").notNull(),
  imageKey: text("imageKey"),
  imageUrl: text("imageUrl"),
  videoKey: text("videoKey"),
  videoUrl: text("videoUrl"),
  textStyle: varchar("textStyle", { length: 40 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const reelLikes = mysqlTable(
  "reel_likes",
  {
    id: serial("id").primaryKey(),
    reelId: varchar("reelId", { length: 80 }).notNull(),
    userId: bigint("userId", { mode: "number", unsigned: true })
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => [uniqueIndex("reel_likes_reel_user_unique").on(table.reelId, table.userId)],
);

export const reelViews = mysqlTable("reel_views", {
  id: serial("id").primaryKey(),
  reelId: varchar("reelId", { length: 80 }).notNull(),
  userId: bigint("userId", { mode: "number", unsigned: true })
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  watchSeconds: int("watchSeconds").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const reelProgress = mysqlTable(
  "reel_progress",
  {
    id: serial("id").primaryKey(),
    reelId: varchar("reelId", { length: 80 }).notNull(),
    userId: bigint("userId", { mode: "number", unsigned: true })
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    positionSeconds: int("positionSeconds").default(0).notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
  },
  (table) => [uniqueIndex("reel_progress_reel_user_unique").on(table.reelId, table.userId)],
);

export const likes = mysqlTable(
  "likes",
  {
    id: serial("id").primaryKey(),
    postId: bigint("postId", { mode: "number", unsigned: true })
      .notNull()
      .references(() => posts.id, { onDelete: "cascade" }),
    userId: bigint("userId", { mode: "number", unsigned: true })
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => [uniqueIndex("likes_post_user_unique").on(table.postId, table.userId)],
);

export const bookmarks = mysqlTable(
  "bookmarks",
  {
    id: serial("id").primaryKey(),
    postId: bigint("postId", { mode: "number", unsigned: true })
      .notNull()
      .references(() => posts.id, { onDelete: "cascade" }),
    userId: bigint("userId", { mode: "number", unsigned: true })
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => [uniqueIndex("bookmarks_post_user_unique").on(table.postId, table.userId)],
);

export const comments = mysqlTable("comments", {
  id: serial("id").primaryKey(),
  postId: bigint("postId", { mode: "number", unsigned: true })
    .notNull()
    .references(() => posts.id, { onDelete: "cascade" }),
  authorId: bigint("authorId", { mode: "number", unsigned: true })
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  content: varchar("content", { length: 500 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const followers = mysqlTable(
  "followers",
  {
    id: serial("id").primaryKey(),
    followerId: bigint("followerId", { mode: "number", unsigned: true })
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    followingId: bigint("followingId", { mode: "number", unsigned: true })
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => [uniqueIndex("followers_pair_unique").on(table.followerId, table.followingId)],
);

export const stories = mysqlTable("stories", {
  id: serial("id").primaryKey(),
  authorId: bigint("authorId", { mode: "number", unsigned: true })
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  content: text("content"),
  imageKey: text("imageKey"),
  imageUrl: text("imageUrl"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  expiresAt: timestamp("expiresAt").notNull(),
});

export const storyViews = mysqlTable(
  "story_views",
  {
    id: serial("id").primaryKey(),
    storyId: bigint("storyId", { mode: "number", unsigned: true })
      .notNull()
      .references(() => stories.id, { onDelete: "cascade" }),
    userId: bigint("userId", { mode: "number", unsigned: true })
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    viewedAt: timestamp("viewedAt").defaultNow().notNull(),
  },
  (table) => [uniqueIndex("story_views_story_user_unique").on(table.storyId, table.userId)],
);

export const reports = mysqlTable(
  "reports",
  {
    id: serial("id").primaryKey(),
    reporterId: bigint("reporterId", { mode: "number", unsigned: true })
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    targetType: mysqlEnum("targetType", ["post", "story", "user"]).notNull(),
    targetId: bigint("targetId", { mode: "number", unsigned: true }).notNull(),
    reason: varchar("reason", { length: 120 }).notNull(),
    details: text("details"),
    status: mysqlEnum("status", ["open", "reviewed", "resolved"]).default("open").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => [uniqueIndex("reports_reporter_target_unique").on(table.reporterId, table.targetType, table.targetId)],
);

export const messages = mysqlTable("messages", {
  id: serial("id").primaryKey(),
  senderId: bigint("senderId", { mode: "number", unsigned: true })
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  recipientId: bigint("recipientId", { mode: "number", unsigned: true })
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  content: varchar("content", { length: 1000 }).notNull(),
  readAt: timestamp("readAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const notifications = mysqlTable("notifications", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true })
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  title: varchar("title", { length: 160 }).notNull(),
  body: varchar("body", { length: 500 }).notNull(),
  kind: mysqlEnum("kind", ["system", "social", "billing"]).default("system").notNull(),
  readAt: timestamp("readAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const supportTickets = mysqlTable("support_tickets", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true })
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  subject: varchar("subject", { length: 160 }).notNull(),
  message: text("message").notNull(),
  status: mysqlEnum("status", ["open", "answered", "closed"]).default("open").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const orders = mysqlTable("orders", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true })
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  referenceCode: varchar("referenceCode", { length: 24 }).notNull().unique(),
  plan: mysqlEnum("plan", ["plus_monthly", "plus_yearly"]).notNull(),
  amount: int("amount").notNull(),
  currency: varchar("currency", { length: 3 }).default("TRY").notNull(),
  status: mysqlEnum("status", ["awaiting_payment", "pending_review", "active", "rejected"])
    .default("awaiting_payment")
    .notNull(),
  paymentMethod: mysqlEnum("paymentMethod", ["bank_transfer"]).default("bank_transfer").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  reviewedAt: timestamp("reviewedAt"),
});

export const files = mysqlTable("files", {
  id: serial("id").primaryKey(),
  key: varchar("key", { length: 600 }).notNull().unique(),
  ownerId: bigint("ownerId", { mode: "number", unsigned: true })
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  name: varchar("name", { length: 512 }).notNull(),
  size: int("size").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const liveStreams = mysqlTable("live_streams", {
  id: serial("id").primaryKey(),
  hostId: bigint("hostId", { mode: "number", unsigned: true })
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  title: varchar("title", { length: 160 }).notNull(),
  category: varchar("category", { length: 40 }).notNull().default("Sohbet"),
  status: mysqlEnum("status", ["live", "ended"]).default("live").notNull(),
  // Latest webcam frame (base64 JPEG data URL) pushed by the host ~1/sn; viewers poll it.
  frame: mediumtext("frame"),
  peakViewers: int("peakViewers").default(0).notNull(),
  startedAt: timestamp("startedAt").defaultNow().notNull(),
  endedAt: timestamp("endedAt"),
});

export const liveMessages = mysqlTable("live_messages", {
  id: serial("id").primaryKey(),
  streamId: bigint("streamId", { mode: "number", unsigned: true })
    .notNull()
    .references(() => liveStreams.id, { onDelete: "cascade" }),
  authorId: bigint("authorId", { mode: "number", unsigned: true })
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  kind: mysqlEnum("kind", ["chat", "system", "tip", "gift"]).default("chat").notNull(),
  content: varchar("content", { length: 500 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const liveViewers = mysqlTable(
  "live_viewers",
  {
    id: serial("id").primaryKey(),
    streamId: bigint("streamId", { mode: "number", unsigned: true })
      .notNull()
      .references(() => liveStreams.id, { onDelete: "cascade" }),
    userId: bigint("userId", { mode: "number", unsigned: true })
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    lastSeenAt: timestamp("lastSeenAt").defaultNow().notNull(),
  },
  (table) => [uniqueIndex("live_viewers_stream_user_unique").on(table.streamId, table.userId)],
);

export const liveReactions = mysqlTable("live_reactions", {
  id: serial("id").primaryKey(),
  streamId: bigint("streamId", { mode: "number", unsigned: true })
    .notNull()
    .references(() => liveStreams.id, { onDelete: "cascade" }),
  userId: bigint("userId", { mode: "number", unsigned: true })
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  count: int("count").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const tips = mysqlTable("tips", {
  id: serial("id").primaryKey(),
  streamId: bigint("streamId", { mode: "number", unsigned: true })
    .notNull()
    .references(() => liveStreams.id, { onDelete: "cascade" }),
  senderId: bigint("senderId", { mode: "number", unsigned: true })
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  recipientId: bigint("recipientId", { mode: "number", unsigned: true })
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  referenceCode: varchar("referenceCode", { length: 24 }).notNull().unique(),
  amount: int("amount").notNull(),
  currency: varchar("currency", { length: 3 }).default("TRY").notNull(),
  status: mysqlEnum("status", ["awaiting_payment", "pending_review", "completed", "rejected"])
    .default("awaiting_payment")
    .notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  reviewedAt: timestamp("reviewedAt"),
});

export const liveGifts = mysqlTable("live_gifts", {
  id: serial("id").primaryKey(),
  streamId: bigint("streamId", { mode: "number", unsigned: true })
    .notNull()
    .references(() => liveStreams.id, { onDelete: "cascade" }),
  senderId: bigint("senderId", { mode: "number", unsigned: true })
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  giftId: varchar("giftId", { length: 40 }).notNull(),
  count: int("count").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const platformSettings = mysqlTable("platform_settings", {
  key: varchar("key", { length: 80 }).primaryKey(),
  value: text("value").notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Post = typeof posts.$inferSelect;
export type Order = typeof orders.$inferSelect;
export type LiveStream = typeof liveStreams.$inferSelect;
export type Tip = typeof tips.$inferSelect;
