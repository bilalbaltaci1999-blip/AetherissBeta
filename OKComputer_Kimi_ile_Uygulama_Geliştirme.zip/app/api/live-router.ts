import { randomBytes } from "node:crypto";
import { TRPCError } from "@trpc/server";
import { and, desc, eq, gt, gte, sql } from "drizzle-orm";
import { z } from "zod";
import { DIAMOND_RATE, GIFT_CATALOG, LiveCategories, TIP_AMOUNTS } from "@contracts/constants";
import { liveGifts, liveMessages, liveReactions, liveStreams, liveViewers, notifications, platformSettings, tips, users } from "@db/schema";
import { resolveUserAvatar } from "./account-auth";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";

const VIEWER_WINDOW_MS = 25_000;
const REACTION_WINDOW_MS = 4_000;
const MAX_FRAME_LENGTH = 1_600_000; // base64 chars (~1.2 MB) — host frames are ~50 KB

type HostInfo = { id: number; name: string; handle: string; avatar: string | null; isVerified: boolean };

async function toHost(user: { id: number; name: string | null; handle: string | null; avatar: string | null; avatarKey: string | null; isVerified: boolean }): Promise<HostInfo> {
  return {
    id: user.id,
    name: user.name ?? "Aetheris Üyesi",
    handle: user.handle ?? "uye",
    avatar: await resolveUserAvatar(user),
    isVerified: user.isVerified,
  };
}

async function viewerCount(streamId: number) {
  const since = new Date(Date.now() - VIEWER_WINDOW_MS);
  const rows = await getDb()
    .select({ n: sql<number>`count(*)` })
    .from(liveViewers)
    .where(and(eq(liveViewers.streamId, streamId), gt(liveViewers.lastSeenAt, since)));
  return Number(rows[0]?.n ?? 0);
}

async function recentReactions(streamId: number) {
  const since = new Date(Date.now() - REACTION_WINDOW_MS);
  const rows = await getDb()
    .select({ n: sql<number>`coalesce(sum(${liveReactions.count}), 0)` })
    .from(liveReactions)
    .where(and(eq(liveReactions.streamId, streamId), gt(liveReactions.createdAt, since)));
  return Number(rows[0]?.n ?? 0);
}

async function paymentDetails() {
  const row = await getDb().query.platformSettings.findFirst({ where: eq(platformSettings.key, "bank_transfer") });
  if (!row) return { accountName: "", bankName: "", iban: "" };
  try {
    return JSON.parse(row.value) as { accountName: string; bankName: string; iban: string };
  } catch {
    return { accountName: "", bankName: "", iban: "" };
  }
}

async function requireLiveStream(streamId: number) {
  const stream = await getDb().query.liveStreams.findFirst({ where: eq(liveStreams.id, streamId) });
  if (!stream) throw new TRPCError({ code: "NOT_FOUND", message: "Yayın bulunamadı." });
  return stream;
}

export const liveRouter = createRouter({
  list: authedQuery.query(async () => {
    const db = getDb();
    const live = await db
      .select({ stream: liveStreams, host: users })
      .from(liveStreams)
      .innerJoin(users, eq(liveStreams.hostId, users.id))
      .where(eq(liveStreams.status, "live"))
      .orderBy(desc(liveStreams.startedAt))
      .limit(24);
    const ended = await db
      .select({ stream: liveStreams, host: users })
      .from(liveStreams)
      .innerJoin(users, eq(liveStreams.hostId, users.id))
      .where(and(eq(liveStreams.status, "ended"), gte(liveStreams.startedAt, new Date(Date.now() - 48 * 60 * 60 * 1000))))
      .orderBy(desc(liveStreams.startedAt))
      .limit(12);

    const liveItems = await Promise.all(
      live.map(async ({ stream, host }) => ({
        id: stream.id,
        title: stream.title,
        category: stream.category,
        startedAt: stream.startedAt,
        hasFrame: Boolean(stream.frame),
        viewerCount: await viewerCount(stream.id),
        host: await toHost(host),
      })),
    );
    const endedItems = await Promise.all(
      ended.map(async ({ stream, host }) => {
        const [msg] = await db
          .select({ n: sql<number>`count(*)` })
          .from(liveMessages)
          .where(eq(liveMessages.streamId, stream.id));
        const [react] = await db
          .select({ n: sql<number>`coalesce(sum(${liveReactions.count}), 0)` })
          .from(liveReactions)
          .where(eq(liveReactions.streamId, stream.id));
        return {
          id: stream.id,
          title: stream.title,
          category: stream.category,
          startedAt: stream.startedAt,
          endedAt: stream.endedAt,
          peakViewers: stream.peakViewers,
          messageCount: Number(msg?.n ?? 0),
          reactionCount: Number(react?.n ?? 0),
          host: await toHost(host),
        };
      }),
    );
    return { live: liveItems, ended: endedItems };
  }),

  start: authedQuery
    .input(z.object({ title: z.string().trim().min(3).max(160), category: z.enum(LiveCategories) }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      // A host can only run one live stream at a time; close a dangling one first.
      await db
        .update(liveStreams)
        .set({ status: "ended", endedAt: new Date(), frame: null })
        .where(and(eq(liveStreams.hostId, ctx.user.id), eq(liveStreams.status, "live")));
      const [{ id }] = await db
        .insert(liveStreams)
        .values({ hostId: ctx.user.id, title: input.title, category: input.category })
        .$returningId();
      await db.insert(liveMessages).values({
        streamId: id,
        authorId: ctx.user.id,
        kind: "system",
        content: `${ctx.user.name ?? "Yayıncı"} canlı yayına başladı`,
      });
      return { id };
    }),

  end: authedQuery.input(z.object({ streamId: z.number() })).mutation(async ({ ctx, input }) => {
    const db = getDb();
    const stream = await requireLiveStream(input.streamId);
    if (stream.hostId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN", message: "Bu yayını yalnızca yayıncı kapatabilir." });
    if (stream.status === "ended") throw new TRPCError({ code: "BAD_REQUEST", message: "Yayın zaten sonlanmış." });

    const current = await viewerCount(stream.id);
    const peak = Math.max(stream.peakViewers, current);
    const endedAt = new Date();
    await db
      .update(liveStreams)
      .set({ status: "ended", endedAt, peakViewers: peak, frame: null })
      .where(eq(liveStreams.id, stream.id));
    await db.insert(liveMessages).values({
      streamId: stream.id,
      authorId: ctx.user.id,
      kind: "system",
      content: "Yayın sona erdi. Katılan herkese teşekkürler.",
    });

    const [msg] = await db.select({ n: sql<number>`count(*)` }).from(liveMessages).where(eq(liveMessages.streamId, stream.id));
    const [react] = await db
      .select({ n: sql<number>`coalesce(sum(${liveReactions.count}), 0)` })
      .from(liveReactions)
      .where(eq(liveReactions.streamId, stream.id));
    const [tip] = await db
      .select({ n: sql<number>`coalesce(sum(${tips.amount}), 0)` })
      .from(tips)
      .where(and(eq(tips.streamId, stream.id), sql`${tips.status} != 'rejected'`));
    const minutes = Math.max(1, Math.round((endedAt.getTime() - stream.startedAt.getTime()) / 60000));
    return {
      minutes,
      peakViewers: peak,
      messageCount: Number(msg?.n ?? 0),
      reactionCount: Number(react?.n ?? 0),
      tipTotal: Number(tip?.n ?? 0),
    };
  }),

  get: authedQuery.input(z.object({ streamId: z.number() })).query(async ({ input }) => {
    const db = getDb();
    const rows = await db
      .select({ stream: liveStreams, host: users })
      .from(liveStreams)
      .innerJoin(users, eq(liveStreams.hostId, users.id))
      .where(eq(liveStreams.id, input.streamId))
      .limit(1);
    if (!rows.length) throw new TRPCError({ code: "NOT_FOUND", message: "Yayın bulunamadı." });
    const { stream, host } = rows[0];
    return {
      id: stream.id,
      title: stream.title,
      category: stream.category,
      status: stream.status,
      startedAt: stream.startedAt,
      endedAt: stream.endedAt,
      peakViewers: stream.peakViewers,
      viewerCount: await viewerCount(stream.id),
      host: await toHost(host),
    };
  }),

  heartbeat: authedQuery.input(z.object({ streamId: z.number() })).mutation(async ({ ctx, input }) => {
    const stream = await requireLiveStream(input.streamId);
    const db = getDb();
    await db
      .insert(liveViewers)
      .values({ streamId: input.streamId, userId: ctx.user.id, lastSeenAt: new Date() })
      .onDuplicateKeyUpdate({ set: { lastSeenAt: new Date() } });
    const count = await viewerCount(input.streamId);
    if (stream.status === "live" && count > stream.peakViewers) {
      await db.update(liveStreams).set({ peakViewers: count }).where(eq(liveStreams.id, stream.id));
    }
    return { viewerCount: count, status: stream.status };
  }),

  chat: authedQuery
    .input(z.object({ streamId: z.number(), sinceId: z.number().default(0) }))
    .query(async ({ input }) => {
      const db = getDb();
      const rows = await db
        .select({ message: liveMessages, author: users })
        .from(liveMessages)
        .innerJoin(users, eq(liveMessages.authorId, users.id))
        .where(and(eq(liveMessages.streamId, input.streamId), gt(liveMessages.id, input.sinceId)))
        .orderBy(liveMessages.id)
        .limit(100);
      return {
        messages: await Promise.all(rows.map(async ({ message, author }) => ({
          id: message.id,
          kind: message.kind,
          content: message.content,
          createdAt: message.createdAt,
          author: await toHost(author),
        }))),
        recentReactions: await recentReactions(input.streamId),
        viewerCount: await viewerCount(input.streamId),
      };
    }),

  sendMessage: authedQuery
    .input(z.object({ streamId: z.number(), content: z.string().trim().min(1).max(300) }))
    .mutation(async ({ ctx, input }) => {
      const stream = await requireLiveStream(input.streamId);
      if (stream.status !== "live") throw new TRPCError({ code: "BAD_REQUEST", message: "Yayın sona erdi, sohbet kapandı." });
      await getDb().insert(liveMessages).values({
        streamId: input.streamId,
        authorId: ctx.user.id,
        kind: "chat",
        content: input.content,
      });
      return { ok: true };
    }),

  react: authedQuery
    .input(z.object({ streamId: z.number(), count: z.number().int().min(1).max(10) }))
    .mutation(async ({ ctx, input }) => {
      const stream = await requireLiveStream(input.streamId);
      if (stream.status !== "live") throw new TRPCError({ code: "BAD_REQUEST", message: "Yayın sona erdi." });
      await getDb().insert(liveReactions).values({ streamId: input.streamId, userId: ctx.user.id, count: input.count });
      return { ok: true };
    }),

  pushFrame: authedQuery
    .input(z.object({ streamId: z.number(), data: z.string().max(MAX_FRAME_LENGTH) }))
    .mutation(async ({ ctx, input }) => {
      const stream = await requireLiveStream(input.streamId);
      if (stream.hostId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN" });
      // Yayın bittiği anda yolda olan bir kare hata değildir; sessizce yutulur.
      if (stream.status !== "live") return { ok: false };
      if (!input.data.startsWith("data:image/jpeg")) throw new TRPCError({ code: "BAD_REQUEST", message: "Geçersiz kare formatı." });
      await getDb().update(liveStreams).set({ frame: input.data }).where(eq(liveStreams.id, stream.id));
      return { ok: true };
    }),

  frame: authedQuery.input(z.object({ streamId: z.number() })).query(async ({ input }) => {
    const rows = await getDb()
      .select({ frame: liveStreams.frame, status: liveStreams.status })
      .from(liveStreams)
      .where(eq(liveStreams.id, input.streamId))
      .limit(1);
    if (!rows.length) throw new TRPCError({ code: "NOT_FOUND" });
    return { frame: rows[0].frame, status: rows[0].status };
  }),

  tip: authedQuery
    .input(z.object({ streamId: z.number(), amount: z.number().refine((n) => (TIP_AMOUNTS as readonly number[]).includes(n), "Geçersiz destek tutarı.") }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const stream = await requireLiveStream(input.streamId);
      if (stream.status !== "live") throw new TRPCError({ code: "BAD_REQUEST", message: "Yayın sona erdi." });
      if (stream.hostId === ctx.user.id) throw new TRPCError({ code: "BAD_REQUEST", message: "Kendi yayınına destek gönderemezsin." });

      const referenceCode = `DST-${randomBytes(4).toString("hex").toUpperCase()}`;
      await db.insert(tips).values({
        streamId: stream.id,
        senderId: ctx.user.id,
        recipientId: stream.hostId,
        referenceCode,
        amount: input.amount,
      });
      const senderName = ctx.user.name ?? "Bir izleyici";
      const amountText = `₺${(input.amount / 100).toLocaleString("tr-TR")}`;
      await db.insert(liveMessages).values({
        streamId: stream.id,
        authorId: ctx.user.id,
        kind: "tip",
        content: `${senderName}, yayıncıya ${amountText} destek sözü verdi`,
      });
      await db.insert(notifications).values({
        userId: stream.hostId,
        title: "Canlı yayında destek aldın",
        body: `${senderName}, “${stream.title}” yayınında ${amountText} destek sözü verdi. Referans: ${referenceCode}`,
        kind: "billing",
      });
      return { referenceCode, amount: input.amount, payment: await paymentDetails() };
    }),

  gifts: authedQuery
    .input(z.object({ streamId: z.number(), sinceId: z.number().default(0) }))
    .query(async ({ input }) => {
      const db = getDb();
      const events = await db
        .select({ gift: liveGifts, sender: users })
        .from(liveGifts)
        .innerJoin(users, eq(liveGifts.senderId, users.id))
        .where(and(eq(liveGifts.streamId, input.streamId), gt(liveGifts.id, input.sinceId)))
        .orderBy(liveGifts.id)
        .limit(100);
      // Bu yayının hediye liderlik tablosu: coin değerine göre ilk 3 (uygulama içinde toplanır)
      const allGifts = await db
        .select()
        .from(liveGifts)
        .where(eq(liveGifts.streamId, input.streamId))
        .orderBy(liveGifts.id)
        .limit(5000);
      const costOf = (giftId: string) => GIFT_CATALOG.find((item) => item.id === giftId)?.coinCost ?? 0;
      const bySender = new Map<number, number>();
      for (const row of allGifts) {
        bySender.set(row.senderId, (bySender.get(row.senderId) ?? 0) + costOf(row.giftId) * row.count);
      }
      const top = [...bySender.entries()].sort((a, b) => b[1] - a[1]).slice(0, 3);
      const leaders = await Promise.all(
        top.map(async ([senderId, coinTotal]) => {
          const sender = await db.query.users.findFirst({ where: eq(users.id, senderId) });
          return sender ? { sender: await toHost(sender), coinTotal } : null;
        }),
      );
      return {
        events: await Promise.all(
          events.map(async ({ gift, sender }) => ({
            id: gift.id,
            giftId: gift.giftId,
            count: gift.count,
            createdAt: gift.createdAt,
            sender: await toHost(sender),
          })),
        ),
        leaderboard: leaders.filter((row) => row !== null),
      };
    }),

  sendGift: authedQuery
    .input(z.object({ streamId: z.number(), giftId: z.string().min(1).max(40), count: z.number().int().min(1).max(99).default(1) }))
    .mutation(async ({ ctx, input }) => {
      const gift = GIFT_CATALOG.find((item) => item.id === input.giftId);
      if (!gift) throw new TRPCError({ code: "BAD_REQUEST", message: "Bilinmeyen hediye." });
      const db = getDb();
      const stream = await requireLiveStream(input.streamId);
      if (stream.status !== "live") throw new TRPCError({ code: "BAD_REQUEST", message: "Yayın sona erdi." });
      if (stream.hostId === ctx.user.id) throw new TRPCError({ code: "BAD_REQUEST", message: "Kendi yayınına hediye gönderemezsin." });

      const totalCost = gift.coinCost * input.count;
      const balance = ctx.user.coinBalance ?? 0;
      if (balance < totalCost) {
        throw new TRPCError({ code: "BAD_REQUEST", message: `Yetersiz coin. Bu hediye ${totalCost} coin gerektiriyor, bakiyen ${balance}.` });
      }

      // Atomik düşüm + elmas aktarımı: koşullu UPDATE ile bakiye korunur
      const updated = await db
        .update(users)
        .set({ coinBalance: sql`${users.coinBalance} - ${totalCost}` })
        .where(and(eq(users.id, ctx.user.id), sql`${users.coinBalance} >= ${totalCost}`));
      const affected = (updated as unknown as { affectedRows?: number }).affectedRows ?? (updated as unknown as number[])[0];
      if (!affected) throw new TRPCError({ code: "BAD_REQUEST", message: "Yetersiz coin bakiyesi." });

      const diamonds = Math.max(1, Math.round(totalCost * DIAMOND_RATE));
      await db.update(users).set({ diamondBalance: sql`${users.diamondBalance} + ${diamonds}` }).where(eq(users.id, stream.hostId));
      await db.insert(liveGifts).values({ streamId: stream.id, senderId: ctx.user.id, giftId: gift.id, count: input.count });

      const senderName = ctx.user.name ?? "Bir izleyici";
      const giftText = input.count > 1 ? `${gift.name} ×${input.count}` : gift.name;
      await db.insert(liveMessages).values({
        streamId: stream.id,
        authorId: ctx.user.id,
        kind: "gift",
        content: `${senderName}, yayıncıya ${giftText} gönderdi`,
      });
      await db.insert(notifications).values({
        userId: stream.hostId,
        title: "Canlı yayında hediye aldın",
        body: `${senderName}, “${stream.title}” yayınında sana ${giftText} gönderdi. +${diamonds} elmas kazandın.`,
        kind: "social",
      });
      const me = await db.query.users.findFirst({ where: eq(users.id, ctx.user.id) });
      return { ok: true, spent: totalCost, coinBalance: me?.coinBalance ?? balance - totalCost, diamondsGranted: diamonds };
    }),

  markTipSent: authedQuery.input(z.object({ referenceCode: z.string().min(4).max(24) })).mutation(async ({ ctx, input }) => {
    const db = getDb();
    const tip = await db.query.tips.findFirst({ where: eq(tips.referenceCode, input.referenceCode) });
    if (!tip || tip.senderId !== ctx.user.id) throw new TRPCError({ code: "NOT_FOUND" });
    if (tip.status !== "awaiting_payment") throw new TRPCError({ code: "BAD_REQUEST" });
    await db.update(tips).set({ status: "pending_review" }).where(eq(tips.id, tip.id));
    return { ok: true };
  }),
});
