import { and, desc, eq, sql } from "drizzle-orm";
import { z } from "zod";
import { Reels } from "@contracts/constants";
import { reelLikes, reelProgress, reelViews } from "@db/schema";
import { createRouter, authedQuery, adminQuery } from "./middleware";
import { getDb } from "./queries/connection";

const reelIdSchema = z.string().trim().min(1).max(80);

async function reelStats(reelId: string) {
  const db = getDb();
  const [likeAgg, viewAgg] = await Promise.all([
    db
      .select({ count: sql<number>`count(*)` })
      .from(reelLikes)
      .where(eq(reelLikes.reelId, reelId)),
    db
      .select({
        views: sql<number>`count(*)`,
        watchers: sql<number>`count(distinct ${reelViews.userId})`,
        seconds: sql<number>`coalesce(sum(${reelViews.watchSeconds}), 0)`,
      })
      .from(reelViews)
      .where(eq(reelViews.reelId, reelId)),
  ]);
  return {
    likeCount: Number(likeAgg[0]?.count ?? 0),
    viewCount: Number(viewAgg[0]?.views ?? 0),
    watcherCount: Number(viewAgg[0]?.watchers ?? 0),
    watchSeconds: Number(viewAgg[0]?.seconds ?? 0),
  };
}

export const reelsRouter = createRouter({
  catalog: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const [likes, views, progressRows] = await Promise.all([
      db.select().from(reelLikes).where(eq(reelLikes.userId, ctx.user.id)),
      db.select().from(reelViews).where(eq(reelViews.userId, ctx.user.id)),
      db.select().from(reelProgress).where(eq(reelProgress.userId, ctx.user.id)),
    ]);
    const likedSet = new Set(likes.map((row) => row.reelId));
    const watchedMap = new Map(views.map((row) => [row.reelId, row.watchSeconds]));
    const progressMap = new Map(progressRows.map((row) => [row.reelId, row.positionSeconds]));

    const stats = await Promise.all(Reels.map((reel) => reelStats(reel.id)));
    return Reels.map((reel, index) => ({
      ...reel,
      likeCount: stats[index].likeCount,
      viewCount: stats[index].viewCount,
      watcherCount: stats[index].watcherCount,
      watchSeconds: stats[index].watchSeconds,
      liked: likedSet.has(reel.id),
      myWatchSeconds: watchedMap.get(reel.id) ?? 0,
      progressSeconds: progressMap.get(reel.id) ?? 0,
    }));
  }),

  toggleLike: authedQuery.input(z.object({ reelId: reelIdSchema })).mutation(async ({ ctx, input }) => {
    const db = getDb();
    if (!Reels.some((reel) => reel.id === input.reelId)) {
      return { liked: false, likeCount: 0 };
    }
    const existing = await db
      .select()
      .from(reelLikes)
      .where(and(eq(reelLikes.reelId, input.reelId), eq(reelLikes.userId, ctx.user.id)))
      .limit(1);
    if (existing.length) {
      await db.delete(reelLikes).where(eq(reelLikes.id, existing[0].id));
    } else {
      await db.insert(reelLikes).values({ reelId: input.reelId, userId: ctx.user.id });
    }
    const stats = await reelStats(input.reelId);
    return { liked: !existing.length, likeCount: stats.likeCount };
  }),

  recordView: authedQuery
    .input(z.object({ reelId: reelIdSchema, watchSeconds: z.number().int().min(1).max(3600) }))
    .mutation(async ({ ctx, input }) => {
      if (!Reels.some((reel) => reel.id === input.reelId)) return { ok: false };
      await getDb().insert(reelViews).values({
        reelId: input.reelId,
        userId: ctx.user.id,
        watchSeconds: input.watchSeconds,
      });
      return { ok: true };
    }),

  saveProgress: authedQuery
    .input(z.object({ reelId: reelIdSchema, positionSeconds: z.number().int().min(0).max(3600) }))
    .mutation(async ({ ctx, input }) => {
      if (!Reels.some((reel) => reel.id === input.reelId)) return { ok: false };
      const db = getDb();
      const existing = await db
        .select()
        .from(reelProgress)
        .where(and(eq(reelProgress.reelId, input.reelId), eq(reelProgress.userId, ctx.user.id)))
        .limit(1);
      if (existing.length) {
        await db
          .update(reelProgress)
          .set({ positionSeconds: input.positionSeconds })
          .where(eq(reelProgress.id, existing[0].id));
      } else {
        await db.insert(reelProgress).values({
          reelId: input.reelId,
          userId: ctx.user.id,
          positionSeconds: input.positionSeconds,
        });
      }
      return { ok: true };
    }),

  myStats: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const [viewAgg, likeAgg, progressRows] = await Promise.all([
      db
        .select({
          reels: sql<number>`count(distinct ${reelViews.reelId})`,
          seconds: sql<number>`coalesce(sum(${reelViews.watchSeconds}), 0)`,
        })
        .from(reelViews)
        .where(eq(reelViews.userId, ctx.user.id)),
      db
        .select({ count: sql<number>`count(*)` })
        .from(reelLikes)
        .where(eq(reelLikes.userId, ctx.user.id)),
      db.select().from(reelProgress).where(eq(reelProgress.userId, ctx.user.id)),
    ]);
    const inProgress = progressRows
      .map((row) => {
        const reel = Reels.find((item) => item.id === row.reelId);
        if (!reel) return null;
        return {
          reelId: reel.id,
          title: reel.title,
          handle: reel.handle,
          poster: reel.poster,
          positionSeconds: row.positionSeconds,
          durationSec: reel.durationSec,
          percent: Math.min(95, Math.round((row.positionSeconds / reel.durationSec) * 100)),
        };
      })
      .filter((row): row is NonNullable<typeof row> => Boolean(row))
      .sort((a, b) => b.percent - a.percent)
      .slice(0, 6);
    return {
      reelsWatched: Number(viewAgg[0]?.reels ?? 0),
      watchSeconds: Number(viewAgg[0]?.seconds ?? 0),
      reelsLiked: Number(likeAgg[0]?.count ?? 0),
      inProgress,
    };
  }),

  adminStats: adminQuery.query(async () => {
    const db = getDb();
    const rows = await db
      .select({
        reelId: reelViews.reelId,
        views: sql<number>`count(*)`,
        watchers: sql<number>`count(distinct ${reelViews.userId})`,
        seconds: sql<number>`coalesce(sum(${reelViews.watchSeconds}), 0)`,
      })
      .from(reelViews)
      .groupBy(reelViews.reelId)
      .orderBy(desc(sql`count(*)`));
    const [likeAgg, totalAgg] = await Promise.all([
      db.select({ count: sql<number>`count(*)` }).from(reelLikes),
      db
        .select({
          views: sql<number>`count(*)`,
          seconds: sql<number>`coalesce(sum(${reelViews.watchSeconds}), 0)`,
        })
        .from(reelViews),
    ]);
    return {
      totalViews: Number(totalAgg[0]?.views ?? 0),
      totalWatchSeconds: Number(totalAgg[0]?.seconds ?? 0),
      totalLikes: Number(likeAgg[0]?.count ?? 0),
      perReel: rows.map((row) => {
        const reel = Reels.find((item) => item.id === row.reelId);
        return {
          reelId: row.reelId,
          title: reel?.title ?? row.reelId,
          author: reel?.author ?? "—",
          views: Number(row.views),
          watchers: Number(row.watchers),
          watchSeconds: Number(row.seconds),
        };
      }),
    };
  }),
});
