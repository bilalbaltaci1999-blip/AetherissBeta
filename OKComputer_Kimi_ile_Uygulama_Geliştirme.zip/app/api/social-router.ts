import { TRPCError } from "@trpc/server";
import { and, desc, eq, gt, inArray, ne, or } from "drizzle-orm";
import { z } from "zod";
import { TEXT_STYLES } from "@contracts/constants";
import {
  bookmarks,
  comments,
  files,
  followers,
  likes,
  messages,
  notifications,
  posts,
  reports,
  stories,
  storyViews,
  supportTickets,
  users,
} from "@db/schema";
import { storage } from "./lib/storage";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { hasActivePlus, resolveUserAvatar } from "./account-auth";
import { ensureSeedData } from "./queries/seed";

async function resolvePostImage(imageKey: string | null, imageUrl: string | null) {
  if (imageUrl) return imageUrl;
  if (!imageKey) return null;
  try {
    return (await storage.getPresignedUrl({ key: imageKey })).url;
  } catch {
    return null;
  }
}

async function resolvePostVideo(videoKey: string | null, videoUrl: string | null) {
  if (videoUrl) return videoUrl;
  if (!videoKey) return null;
  try {
    return (await storage.getPresignedUrl({ key: videoKey })).url;
  } catch {
    return null;
  }
}

async function resolveStoryImage(imageKey: string | null, imageUrl: string | null) {
  if (imageUrl) return imageUrl;
  if (!imageKey) return null;
  try {
    return (await storage.getPresignedUrl({ key: imageKey })).url;
  } catch {
    return null;
  }
}

export const socialRouter = createRouter({
  feed: authedQuery.query(async ({ ctx }) => {
    await ensureSeedData();
    const db = getDb();
    const rows = await db
      .select({ post: posts, author: users })
      .from(posts)
      .innerJoin(users, eq(posts.authorId, users.id))
      .orderBy(desc(posts.createdAt))
      .limit(60);
    if (!rows.length) return [];
    const ids = rows.map((row) => row.post.id);
    const [allLikes, allComments, allBookmarks] = await Promise.all([
      db.select().from(likes).where(inArray(likes.postId, ids)),
      db.select().from(comments).where(inArray(comments.postId, ids)),
      db.select().from(bookmarks).where(inArray(bookmarks.postId, ids)),
    ]);
    return Promise.all(
      rows.map(async ({ post, author }) => ({
        id: post.id,
        content: post.content,
        textStyle: post.textStyle,
        imageUrl: await resolvePostImage(post.imageKey, post.imageUrl),
        videoUrl: await resolvePostVideo(post.videoKey, post.videoUrl),
        createdAt: post.createdAt,
        author: {
          id: author.id,
          name: author.name ?? "Aetheris Üyesi",
          handle: author.handle ?? "uye",
          avatar: await resolveUserAvatar(author),
          isVerified: author.isVerified,
        },
        likeCount: allLikes.filter((like) => like.postId === post.id).length,
        commentCount: allComments.filter((comment) => comment.postId === post.id).length,
        liked: allLikes.some((like) => like.postId === post.id && like.userId === ctx.user.id),
        bookmarked: allBookmarks.some((mark) => mark.postId === post.id && mark.userId === ctx.user.id),
      })),
    );
  }),

  createPost: authedQuery
    .input(z.object({
      content: z.string().trim().min(1).max(1200),
      imageKey: z.string().max(600).optional(),
      videoKey: z.string().max(600).optional(),
      textStyle: z.string().max(40).optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const maxLength = hasActivePlus(ctx.user) ? 1200 : 500;
      if (input.content.length > maxLength) throw new TRPCError({ code: "BAD_REQUEST", message: `Ücretsiz hesaplarda gönderiler en fazla ${maxLength} karakter olabilir.` });
      for (const key of [input.imageKey, input.videoKey]) {
        if (!key) continue;
        const owned = await getDb().query.files.findFirst({ where: eq(files.key, key) });
        if (!owned || owned.ownerId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN" });
      }
      const style = TEXT_STYLES.some((item) => item.id === input.textStyle) ? input.textStyle : null;
      await getDb().insert(posts).values({
        authorId: ctx.user.id,
        content: input.content,
        imageKey: input.imageKey,
        videoKey: input.videoKey,
        textStyle: style,
      });
      return { ok: true };
    }),

  toggleLike: authedQuery.input(z.object({ postId: z.number() })).mutation(async ({ ctx, input }) => {
    const db = getDb();
    const existing = await db
      .select()
      .from(likes)
      .where(and(eq(likes.postId, input.postId), eq(likes.userId, ctx.user.id)))
      .limit(1);
    if (existing.length) {
      await db.delete(likes).where(eq(likes.id, existing[0].id));
      return { liked: false };
    }
    await db.insert(likes).values({ postId: input.postId, userId: ctx.user.id });
    return { liked: true };
  }),

  toggleBookmark: authedQuery.input(z.object({ postId: z.number() })).mutation(async ({ ctx, input }) => {
    const db = getDb();
    const existing = await db
      .select()
      .from(bookmarks)
      .where(and(eq(bookmarks.postId, input.postId), eq(bookmarks.userId, ctx.user.id)))
      .limit(1);
    if (existing.length) {
      await db.delete(bookmarks).where(eq(bookmarks.id, existing[0].id));
      return { bookmarked: false };
    }
    await db.insert(bookmarks).values({ postId: input.postId, userId: ctx.user.id });
    return { bookmarked: true };
  }),

  comments: authedQuery.input(z.object({ postId: z.number() })).query(async ({ input }) => {
    const rows = await getDb()
      .select({ comment: comments, author: users })
      .from(comments)
      .innerJoin(users, eq(comments.authorId, users.id))
      .where(eq(comments.postId, input.postId))
      .orderBy(desc(comments.createdAt));
    return Promise.all(rows.map(async (row) => ({ ...row, author: { ...row.author, avatar: await resolveUserAvatar(row.author) } })));
  }),

  addComment: authedQuery
    .input(z.object({ postId: z.number(), content: z.string().trim().min(1).max(500) }))
    .mutation(async ({ ctx, input }) => {
      await getDb().insert(comments).values({
        postId: input.postId,
        authorId: ctx.user.id,
        content: input.content,
      });
      return { ok: true };
    }),

  people: authedQuery.query(async ({ ctx }) => {
    await ensureSeedData();
    const rows = await getDb()
      .select({
        id: users.id,
        name: users.name,
        handle: users.handle,
        avatar: users.avatar,
        avatarKey: users.avatarKey,
        bio: users.bio,
        gender: users.gender,
        isVerified: users.isVerified,
      })
      .from(users)
      .where(ne(users.id, ctx.user.id))
      .limit(12);
    const ids = rows.map((row) => row.id);
    if (!ids.length) return [];
    const relations = await getDb()
      .select()
      .from(followers)
      .where(or(inArray(followers.followerId, ids), inArray(followers.followingId, ids)));
    return Promise.all(rows.map(async (row) => ({
      ...row,
      avatar: await resolveUserAvatar(row),
      followerCount: relations.filter((item) => item.followingId === row.id).length,
      followingCount: relations.filter((item) => item.followerId === row.id).length,
      isFollowing: relations.some((item) => item.followerId === ctx.user.id && item.followingId === row.id),
    })));
  }),

  toggleFollow: authedQuery.input(z.object({ userId: z.number() })).mutation(async ({ ctx, input }) => {
    if (input.userId === ctx.user.id) throw new TRPCError({ code: "BAD_REQUEST", message: "Kendini takip edemezsin." });
    const db = getDb();
    const target = await db.query.users.findFirst({ where: eq(users.id, input.userId) });
    if (!target) throw new TRPCError({ code: "NOT_FOUND", message: "Kullanıcı bulunamadı." });
    const existing = await db
      .select()
      .from(followers)
      .where(and(eq(followers.followerId, ctx.user.id), eq(followers.followingId, input.userId)))
      .limit(1);
    if (existing.length) {
      await db.delete(followers).where(eq(followers.id, existing[0].id));
      return { following: false };
    }
    await db.insert(followers).values({ followerId: ctx.user.id, followingId: input.userId });
    await db.insert(notifications).values({
      userId: input.userId,
      title: `${ctx.user.name ?? "Bir üye"} seni takip etmeye başladı`,
      body: `@${ctx.user.handle} artık güncellemelerinden haberdar olacak.`,
      kind: "social",
    });
    return { following: true };
  }),

  report: authedQuery
    .input(z.object({
      targetType: z.enum(["post", "story", "user"]),
      targetId: z.number(),
      reason: z.string().trim().min(3).max(120),
      details: z.string().trim().max(1200).optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      await getDb()
        .insert(reports)
        .values({ reporterId: ctx.user.id, ...input })
        .onDuplicateKeyUpdate({ set: { reason: input.reason, details: input.details ?? null, status: "open", createdAt: new Date() } });
      return { ok: true };
    }),

  updateProfile: authedQuery
    .input(
      z.object({
        name: z.string().trim().min(2).max(80),
        handle: z.string().trim().toLowerCase().regex(/^[a-z0-9_]{3,24}$/),
        bio: z.string().trim().max(240),
        gender: z.enum(["woman", "man", "nonbinary", "prefer_not_to_say"]),
        avatar: z.string().url().or(z.literal("")),
        avatarKey: z.string().max(600).optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const duplicate = await getDb()
        .select({ id: users.id })
        .from(users)
        .where(and(eq(users.handle, input.handle), ne(users.id, ctx.user.id)))
        .limit(1);
      if (duplicate.length) throw new TRPCError({ code: "CONFLICT", message: "Bu kullanıcı adı kullanılıyor." });

      let avatar = input.avatar || ctx.user.avatar;
      let avatarKey = input.avatarKey ?? null;
      if (avatarKey) {
        const owned = await getDb().query.files.findFirst({ where: eq(files.key, avatarKey) });
        if (!owned || owned.ownerId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN", message: "Profil fotoğrafına erişilemiyor." });
        avatar = await resolveUserAvatar({ avatar, avatarKey });
      }

      await getDb()
        .update(users)
        .set({ name: input.name, handle: input.handle, bio: input.bio, gender: input.gender, avatar, avatarKey })
        .where(eq(users.id, ctx.user.id));
      return { ok: true, avatar };
    }),

  updatePrivacy: authedQuery.input(z.object({ isPrivate: z.boolean() })).mutation(async ({ ctx, input }) => {
    await getDb().update(users).set({ isPrivate: input.isPrivate }).where(eq(users.id, ctx.user.id));
    return { ok: true };
  }),

  stories: authedQuery.query(async ({ ctx }) => {
    await ensureSeedData();
    const db = getDb();
    const rows = await db
      .select({ story: stories, author: users })
      .from(stories)
      .innerJoin(users, eq(stories.authorId, users.id))
      .where(gt(stories.expiresAt, new Date()))
      .orderBy(desc(stories.createdAt))
      .limit(80);
    if (!rows.length) return [];
    const ids = rows.map((row) => row.story.id);
    const views = await db.select().from(storyViews).where(inArray(storyViews.storyId, ids));
    return Promise.all(rows.map(async ({ story, author }) => ({
      id: story.id,
      content: story.content,
      imageUrl: await resolveStoryImage(story.imageKey, story.imageUrl),
      createdAt: story.createdAt,
      expiresAt: story.expiresAt,
      author: {
        id: author.id,
        name: author.name ?? "Aetheris Üyesi",
        handle: author.handle ?? "uye",
        avatar: await resolveUserAvatar(author),
        isVerified: author.isVerified,
      },
      seen: views.some((view) => view.storyId === story.id && view.userId === ctx.user.id),
      viewCount: views.filter((view) => view.storyId === story.id).length,
    })));
  }),

  createStory: authedQuery
    .input(z.object({
      content: z.string().trim().max(220).optional(),
      imageKey: z.string().max(600).optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      if (!input.content && !input.imageKey) throw new TRPCError({ code: "BAD_REQUEST", message: "Hikâye için kısa bir not ya da görsel ekle." });
      if (input.imageKey) {
        const owned = await getDb().query.files.findFirst({ where: eq(files.key, input.imageKey) });
        if (!owned || owned.ownerId !== ctx.user.id) throw new TRPCError({ code: "FORBIDDEN" });
      }
      await getDb().insert(stories).values({
        authorId: ctx.user.id,
        content: input.content,
        imageKey: input.imageKey,
        expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000),
      });
      return { ok: true };
    }),

  viewStory: authedQuery.input(z.object({ storyId: z.number() })).mutation(async ({ ctx, input }) => {
    await getDb()
      .insert(storyViews)
      .values({ storyId: input.storyId, userId: ctx.user.id })
      .onDuplicateKeyUpdate({ set: { viewedAt: new Date() } });
    return { ok: true };
  }),

  mySocialStats: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const [followerRows, followingRows, storyRows] = await Promise.all([
      db.select().from(followers).where(eq(followers.followingId, ctx.user.id)),
      db.select().from(followers).where(eq(followers.followerId, ctx.user.id)),
      db.select().from(stories).where(eq(stories.authorId, ctx.user.id)),
    ]);
    return { followerCount: followerRows.length, followingCount: followingRows.length, storyCount: storyRows.length };
  }),

  conversations: authedQuery.query(async ({ ctx }) => {
    await ensureSeedData();
    const rows = await getDb()
      .select({ id: users.id, name: users.name, handle: users.handle, avatar: users.avatar, avatarKey: users.avatarKey, isVerified: users.isVerified })
      .from(users)
      .where(ne(users.id, ctx.user.id))
      .limit(10);
    return Promise.all(rows.map(async (row) => ({ ...row, avatar: await resolveUserAvatar(row) })));
  }),

  conversation: authedQuery.input(z.object({ userId: z.number() })).query(async ({ ctx, input }) => {
    return getDb()
      .select()
      .from(messages)
      .where(
        or(
          and(eq(messages.senderId, ctx.user.id), eq(messages.recipientId, input.userId)),
          and(eq(messages.senderId, input.userId), eq(messages.recipientId, ctx.user.id)),
        ),
      )
      .orderBy(messages.createdAt);
  }),

  sendMessage: authedQuery
    .input(z.object({ recipientId: z.number(), content: z.string().trim().min(1).max(1000) }))
    .mutation(async ({ ctx, input }) => {
      await getDb().insert(messages).values({
        senderId: ctx.user.id,
        recipientId: input.recipientId,
        content: input.content,
      });
      return { ok: true };
    }),

  notifications: authedQuery.query(async ({ ctx }) => {
    await ensureSeedData();
    return getDb()
      .select()
      .from(notifications)
      .where(eq(notifications.userId, ctx.user.id))
      .orderBy(desc(notifications.createdAt))
      .limit(40);
  }),

  markNotificationsRead: authedQuery.mutation(async ({ ctx }) => {
    await getDb().update(notifications).set({ readAt: new Date() }).where(eq(notifications.userId, ctx.user.id));
    return { ok: true };
  }),

  tickets: authedQuery.query(async ({ ctx }) => {
    return getDb()
      .select()
      .from(supportTickets)
      .where(eq(supportTickets.userId, ctx.user.id))
      .orderBy(desc(supportTickets.createdAt));
  }),

  createTicket: authedQuery
    .input(z.object({ subject: z.string().trim().min(3).max(160), message: z.string().trim().min(10).max(3000) }))
    .mutation(async ({ ctx, input }) => {
      await getDb().insert(supportTickets).values({ userId: ctx.user.id, ...input });
      return { ok: true };
    }),
});
