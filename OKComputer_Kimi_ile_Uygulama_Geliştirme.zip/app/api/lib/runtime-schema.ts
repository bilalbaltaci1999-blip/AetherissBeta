import mysql from "mysql2/promise";
import { log } from "./logger";

/**
 * Çevrimiçi şema kendini iyileştirme (additive-only, idempotent).
 *
 * Neden var: sürüm kaydetme hattı `db:push` çalıştırmaz ve export edilmiş
 * projede `.env` olmadığı için geliştirme kutusundan `db:push` atılamaz.
 * Bu yüzden sunucu her ayağa kalkışta yeni eklenen sütunları/tabloları
 * information_schema üzerinden kontrol eder, yoksa guarded DDL ile ekler.
 * Yalnızca ekleme yapar; hiçbir sütunu/tabloyu düşürmez veya değiştirmez.
 */

type ColumnSpec = { table: string; column: string; ddl: string };

const NEW_COLUMNS: ColumnSpec[] = [
  { table: "users", column: "coinBalance", ddl: "ALTER TABLE `users` ADD COLUMN `coinBalance` int NOT NULL DEFAULT 2000" },
  { table: "users", column: "diamondBalance", ddl: "ALTER TABLE `users` ADD COLUMN `diamondBalance` int NOT NULL DEFAULT 0" },
  { table: "users", column: "lastDailyCoinsAt", ddl: "ALTER TABLE `users` ADD COLUMN `lastDailyCoinsAt` timestamp NULL" },
  { table: "posts", column: "textStyle", ddl: "ALTER TABLE `posts` ADD COLUMN `textStyle` varchar(40) NULL" },
];

/** ENUM değeri eklenen sütunlar: COLUMN_TYPE içinde yeni değer geçmiyorsa MODIFY ile genişlet. */
const ENUM_EXTENSIONS: { table: string; column: string; value: string; ddl: string }[] = [
  {
    table: "live_messages",
    column: "kind",
    value: "gift",
    ddl: "ALTER TABLE `live_messages` MODIFY COLUMN `kind` enum('chat','system','tip','gift') NOT NULL DEFAULT 'chat'",
  },
];

const NEW_TABLES: string[] = [
  `CREATE TABLE IF NOT EXISTS \`live_gifts\` (
    \`id\` bigint unsigned NOT NULL AUTO_INCREMENT,
    \`streamId\` bigint unsigned NOT NULL,
    \`senderId\` bigint unsigned NOT NULL,
    \`giftId\` varchar(40) NOT NULL,
    \`count\` int NOT NULL DEFAULT 1,
    \`createdAt\` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (\`id\`),
    KEY \`live_gifts_stream_idx\` (\`streamId\`, \`id\`),
    CONSTRAINT \`live_gifts_stream_fk\` FOREIGN KEY (\`streamId\`) REFERENCES \`live_streams\` (\`id\`) ON DELETE CASCADE,
    CONSTRAINT \`live_gifts_sender_fk\` FOREIGN KEY (\`senderId\`) REFERENCES \`users\` (\`id\`) ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
];

let started = false;

export async function ensureRuntimeSchema() {
  if (started) return;
  started = true;
  const url = process.env.DATABASE_URL;
  if (!url) {
    log.warn("runtime schema check skipped: DATABASE_URL yok");
    return;
  }
  let connection: mysql.Connection | undefined;
  try {
    connection = await mysql.createConnection(url);
    const [rows] = await connection.query(
      "SELECT TABLE_NAME AS tableName, COLUMN_NAME AS columnName, COLUMN_TYPE AS columnType FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE()",
    );
    const columns = rows as { tableName: string; columnName: string; columnType: string }[];
    const existing = new Set(columns.map((r) => `${r.tableName}.${r.columnName}`));

    for (const spec of ENUM_EXTENSIONS) {
      const col = columns.find((r) => r.tableName === spec.table && r.columnName === spec.column);
      if (!col || col.columnType.includes(`'${spec.value}'`)) continue;
      log.info("runtime schema: extending enum", { table: spec.table, column: spec.column, value: spec.value });
      await connection.query(spec.ddl);
    }

    for (const spec of NEW_COLUMNS) {
      if (existing.has(`${spec.table}.${spec.column}`)) continue;
      log.info("runtime schema: adding column", { table: spec.table, column: spec.column });
      await connection.query(spec.ddl);
    }
    for (const ddl of NEW_TABLES) {
      await connection.query(ddl);
    }
  } catch (error) {
    // Şema güncellemesi başarısız olursa istekler 500 vermesin diye logla ve devam et.
    log.error("runtime schema check failed", { error: error instanceof Error ? error.message : String(error) });
  } finally {
    await connection?.end().catch(() => undefined);
  }
}
