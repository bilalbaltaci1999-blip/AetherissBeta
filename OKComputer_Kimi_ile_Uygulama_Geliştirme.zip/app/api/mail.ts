import nodemailer from "nodemailer";
import { log } from "./lib/logger";

/**
 * Şifre sıfırlama e-postaları varsayılan olarak aetherisback2027@gmail.com
 * hesabından gönderilir. Gmail ile gerçek gönderim için iki kurulum yolu var:
 *
 * 1) GMAIL_APP_PASSWORD: Gmail hesabında 2FA açıkken üretilen 16 haneli "uygulama
 *    şifresi". SMTP_HOST tanımlı değilse otomatik olarak smtp.gmail.com:465
 *    kullanılır ve gönderen adresi GMAIL_USER (varsayılan aetherisback2027@gmail.com) olur.
 *
 * 2) Generic SMTP: SMTP_HOST / SMTP_PORT / SMTP_USER / SMTP_PASS / SMTP_FROM.
 *
 * Hiçbiri tanımlı değilse geliştirme modunda bağlantı ekranda önizlenir (previewUrl);
*  üretimde e-posta gönderilemez ancak akış güvenli şekilde "gönderildi" yanıtı verir.
 */
export const DEFAULT_SENDER = "aetherisback2027@gmail.com";

export function mailConfig() {
  const gmailPass = process.env.GMAIL_APP_PASSWORD;
  const genericHost = process.env.SMTP_HOST;
  if (gmailPass && !genericHost) {
    return {
      host: "smtp.gmail.com",
      port: 465,
      secure: true,
      auth: { user: process.env.GMAIL_USER || DEFAULT_SENDER, pass: gmailPass },
      from: process.env.SMTP_FROM || process.env.GMAIL_USER || DEFAULT_SENDER,
    };
  }
  if (genericHost) {
    const port = Number(process.env.SMTP_PORT ?? 587);
    return {
      host: genericHost,
      port,
      secure: port === 465,
      auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } : undefined,
      from: process.env.SMTP_FROM || process.env.SMTP_USER || DEFAULT_SENDER,
    };
  }
  return null;
}

export function isMailConfigured() {
  return mailConfig() !== null;
}

export async function sendPasswordResetEmail(to: string, resetUrl: string) {
  const config = mailConfig();
  if (!config) return false;
  const { from, ...transportConfig } = config;
  const transporter = nodemailer.createTransport(transportConfig);
  try {
    await transporter.sendMail({
      from: `Aetheris <${from}>`,
      to,
      subject: "Aetheris şifre sıfırlama bağlantın",
      text: `Şifreni sıfırlamak için bu bağlantıyı aç: ${resetUrl}\n\nBağlantı 30 dakika geçerlidir ve yalnızca bir kez kullanılabilir. Bu isteği sen yapmadıysan bu e-postayı yok say.`,
      html: `<div style="font-family:Arial,sans-serif;background:#121212;color:#ffffff;padding:32px"><div style="max-width:520px;margin:auto"><p style="color:#40aaff;font-weight:bold;letter-spacing:2px">AETHERIS</p><h1>Şifreni yenile</h1><p style="line-height:1.6;color:#d4d4d4">Aşağıdaki düğmeyle yeni bir şifre belirleyebilirsin. Bağlantı 30 dakika geçerlidir ve yalnızca bir kez kullanılabilir.</p><p><a href="${resetUrl}" style="display:inline-block;background:#40aaff;color:#121212;text-decoration:none;font-weight:bold;padding:14px 22px;border-radius:6px">Şifreyi sıfırla</a></p><p style="font-size:12px;color:#a3a3a3">Bu isteği sen yapmadıysan bu e-postayı yok say.</p></div></div>`,
    });
    return true;
  } catch (error) {
    log.error("password reset email failed", {
      error: error instanceof Error ? error.message : String(error),
    });
    return false;
  }
}
