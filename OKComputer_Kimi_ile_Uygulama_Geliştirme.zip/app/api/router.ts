import { accountRouter } from "./account-router";
import { authRouter } from "./auth-router";
import { commerceRouter } from "./commerce-router";
import { liveRouter } from "./live-router";
import { reelsRouter } from "./reels-router";
import { socialRouter } from "./social-router";
import { storageRouter } from "./storage-router";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  account: accountRouter,
  social: socialRouter,
  live: liveRouter,
  commerce: commerceRouter,
  storage: storageRouter,
  reels: reelsRouter,
});

export type AppRouter = typeof appRouter;
